import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from sklearn.model_selection import KFold
from sklearn.preprocessing import label_binarize
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, mean_squared_error, roc_curve, auc
from sklearn.metrics import cohen_kappa_score, matthews_corrcoef, r2_score
import numpy as np
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader, Dataset, random_split, Subset
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
from scipy.stats import pearsonr
import os
from torch.cuda import amp
import argparse
import scipy
import warnings
import time

warnings.filterwarnings("ignore")

class SimpleNN(nn.Module):
    def __init__(self, input_size, num_classes):
        super(SimpleNN, self).__init__()
        self.fc = nn.Sequential(
                    nn.Sequential(nn.Linear(input_size, 1024),
                      nn.ReLU(),
                      nn.Dropout(0.2),
                      nn.Linear(1024, 256),
                      nn.ReLU(),
                      nn.Dropout(0.2),
                      nn.Linear(256, num_classes),
                      nn.Sigmoid()
                      )
        )

    def forward(self, x):
        return self.fc(x)

class MyDataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sample = self.data[idx]
        sample = torch.tensor(sample)
        label = self.labels[idx]
        label = torch.tensor(label)
        return sample, label


def calculate_metrics(y_true, y_pred, y_val_bin, num_classes):
    y_pred_class = np.argmax(y_pred, axis=1)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(y_pred.shape[1]):
        fpr[i], tpr[i], _ = roc_curve(y_val_bin[:, i], y_pred[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    values = [v for v in roc_auc.values() if not np.isnan(v)]
    mean_value = np.mean(values)
    Auc = mean_value

    metrics = {}
    metrics['RMSE'] = np.sqrt(mean_squared_error(y_true, y_pred_class))
    metrics['PCC'], _ = pearsonr(y_true.flatten(), y_pred_class.flatten())
    metrics['ACC'] = accuracy_score(y_true, y_pred_class)
    metrics['Precision'] = precision_score(y_true, y_pred_class, average='macro')
    metrics['F1'] = f1_score(y_true, y_pred_class, average='macro')
    metrics['Recall'] = recall_score(y_true, y_pred_class, average='macro')
    metrics['AUC'] = Auc
    metrics['Kappa'] = cohen_kappa_score(y_true, y_pred_class)
    metrics['PREC'] = precision_score(y_true, y_pred_class, average='micro')  # 可以根据需求自定义

    return metrics
def main():

    current_directory = os.getcwd()
    folder_path = os.path.join(current_directory, 'data', '8anti_mat', 'Redo')
    mat_files = [f for f in os.listdir(folder_path) if f.endswith('.mat')]


    for mat_file in mat_files:

        current_file_name = mat_file[-11:-4]

        file_path = os.path.join(folder_path, mat_file)

        mat_data = scipy.io.loadmat(file_path)
        morgan = mat_data['morgan']
        enzyme = mat_data['enzyme']
        target = mat_data['target']
        pathway = mat_data['pathway']
        gnd = np.squeeze(mat_data['gnd'])
        gnd_unique = np.unique(gnd)
        replace_dict = {old_value: new_value for new_value, old_value in enumerate(gnd_unique)}
        replace_func = np.vectorize(replace_dict.get)
        new_gnd = replace_func(gnd)
        X = morgan
        y = new_gnd
        y_bin = label_binarize(y, classes=list(range(len(gnd_unique))))




        kf = KFold(n_splits=5, shuffle=True, random_state=42)
        dataset = MyDataset(X,y)
        fold_results = []


        for fold, (train_idx, val_idx) in enumerate(kf.split(dataset)):
            print(f'Fold {fold}')
            train_dataset = Subset(dataset, train_idx)
            test_dataset = Subset(dataset, train_idx)
            y_val_bin = y_bin[train_idx]
            #train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
            train_loader = DataLoader(train_dataset, batch_size=64, shuffle=False)
            test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)
            start_epoch = 0
            max_test_acc = 0
            parser = argparse.ArgumentParser(description='Classify Fashion-MNIST')
            parser.add_argument('-T', default=10, type=int, help='simulating time-steps')
            parser.add_argument('-device', default='cuda:0', help='device')
            parser.add_argument('-b', default=32, type=int, help='batch size')
            parser.add_argument('-epochs', default=10, type=int, metavar='N',
                                help='number of total epochs to run')
            parser.add_argument('-j', default=1, type=int, metavar='N',
                                help='number of data loading workers (default: 4)')
            parser.add_argument('-out_dir', type=str, default='./logs', help='root dir for saving logs and checkpoint')
            parser.add_argument('-resume', type=str, help='resume from the checkpoint path')
            parser.add_argument('-amp', action='store_true', help='automatic mixed precision training')
            parser.add_argument('-opt', default='Adam', type=str, help='use which optimizer. SDG or Adam')
            parser.add_argument('-lr', default=0.001, type=float, help='learning rate')
            parser.add_argument('-momentum', default=0.9, type=float, help='momentum for SGD')
            parser.add_argument('-lr_scheduler', default='CosALR', type=str, help='use which schedule. StepLR or CosALR')
            parser.add_argument('-step_size', default=32, type=float, help='step_size for StepLR')
            parser.add_argument('-gamma', default=0.1, type=float, help='gamma for StepLR')
            parser.add_argument('-T_max', default=64, type=int, help='T_max for CosineAnnealingLR')
            args = parser.parse_args()
            print(args)

            net = SimpleNN(input_size=4098, num_classes=len(gnd_unique))
            net.to(args.device)#
            optimizer = None
            if args.opt == 'SDG':
                optimizer = torch.optim.SGD(net.parameters(), lr=args.lr, momentum=args.momentum)
            elif args.opt == 'Adam':
                optimizer = torch.optim.Adam(net.parameters(), lr=args.lr)
            else:
                raise NotImplementedError(args.opt)
            scaler = None
            lr_scheduler = None
            if args.lr_scheduler == 'StepLR':
                lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=args.step_size, gamma=args.gamma)
            elif args.lr_scheduler == 'CosALR':
                lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.T_max)
            else:
                raise NotImplementedError(args.lr_scheduler)
            criterion = nn.CrossEntropyLoss()
            #optimizer = optim.Adam(model.parameters(), lr=0.01)
            #optimizer = torch.optim.SGD(model.parameters(), lr=0.001, momentum=0.5)

            for epoch in range(start_epoch, args.epochs):
                start_time = time.time()
                net.train()
                train_loss = 0
                train_acc = 0
                train_samples = 0
                for data, target in train_loader:
                    optimizer.zero_grad()
                    data = data.to(args.device).float()
                    target = target.to(args.device)
                    target = target.long()
                    target_onehot = F.one_hot(target, len(gnd_unique)).float()
                    if args.amp:
                        with amp.autocast():
                            out_fr = net(data)
                            loss = F.mse_loss(out_fr, target_onehot)
                        scaler.scale(loss).backward()
                        scaler.step(optimizer)
                        scaler.update()
                    else:
                        out_fr = net(data)
                        loss = F.mse_loss(out_fr, target_onehot)
                        loss.backward()
                        optimizer.step()

                    train_samples += target.numel()
                    train_loss += loss.item() * target.numel()
                    train_acc += (out_fr.argmax(1) == target).float().sum().item()

                project_root = os.getcwd()
                out_dir = os.path.join(project_root)
                train_loss /= train_samples
                train_acc /= train_samples
                writer = SummaryWriter(os.path.join(out_dir, 'TR_logs'), purge_step=start_epoch)
                writer.add_scalar('train_loss', train_loss, epoch)
                writer.add_scalar('train_acc', train_acc, epoch)
                lr_scheduler.step()

                net.eval()
                test_loss = 0
                test_acc = 0
                test_samples = 0
                all_outputs = []
                all_targets = []
                with torch.no_grad():
                    for data, target in test_loader:
                        optimizer.zero_grad()
                        data = data.to(args.device).float()
                        target = target.to(args.device)
                        target = target.long()
                        target_onehot = F.one_hot(target, len(gnd_unique)).float()
                        out_fr = net(data)
                        loss = F.mse_loss(out_fr, target_onehot)

                        test_samples += target.numel()
                        test_loss += loss.item() * target.numel()
                        test_acc += (out_fr.argmax(1) == target).float().sum().item()
                        all_outputs.append(out_fr.cpu().numpy())
                        all_targets.append(target.cpu().numpy())

            #val_pred, val_true = np.concatenate(all_outputs), np.concatenate(all_targets)


                test_loss /= test_samples
                test_acc /= test_samples
                writer.add_scalar('test_loss', test_loss, epoch)
                writer.add_scalar('test_acc', test_acc, epoch)

                print(
                    f'epoch={epoch}, train_loss={train_loss}, train_acc={train_acc}, test_loss={test_loss}, test_acc={test_acc}, max_test_acc={max_test_acc}, total_time={time.time() - start_time}')
            val_pred, val_true = np.concatenate(all_outputs), np.concatenate(all_targets)
            metrics = calculate_metrics(val_true, val_pred,y_val_bin, num_classes=len(gnd_unique))
            fold_results.append(metrics)

        final_results = {}
        for metric in fold_results[0].keys():
            values = [fold[metric] for fold in fold_results]
            final_results[f'{metric}_mean'] = np.mean(values)
            final_results[f'{metric}_std'] = np.std(values)

        current_directory = os.getcwd()
        output_dir = os.path.join(current_directory, 'data', 'table', 'DeepSy')
        filename = current_file_name
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        output_path = os.path.join(output_dir, filename + '.csv')
        df = pd.DataFrame(final_results, index=[0])
        df.to_csv(output_path, index=False)
        result = current_file_name + "   Acc: " + str(final_results['ACC_mean'])
        print(result)

if __name__ == '__main__':
    main()