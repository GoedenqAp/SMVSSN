import torch
import numpy as np
import time
import os
#os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
from sklearn.datasets import fetch_lfw_people
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
from skimage.transform import resize
from torch.utils.data import DataLoader, Dataset, random_split
import os
import scipy
import pandas as pd

class SNN_In_Pytorch():
    def __init__(self):
        pass

    def code(self, in_channels, out_channels, stride, padding, input_map, input_MP, threhold=1.0, mode=0):
        input_MP += input_map
        internal_map = torch.zeros(input_map.shape).cuda().half()
        internal_map[torch.where(input_MP >= threhold)] = 1
        input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        return input_MP, internal_map

    def SNN_ConV(self, in_channels, out_channels, stride, padding, input_map, weight, input_MP, threhold=1.0, mode=0):
        c = torch.nn.Conv1d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, stride=stride,
                            padding=padding, bias=False).cuda().half()
        c.weight.data = weight
        internal_result = c(input_map)
        # input_MP += internal_result
        if (mode == 0):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 1):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        elif (mode == 2):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 3):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        return input_MP, internal_map

    def SNN_Average_Pooling(self, input_map, input_MP, threhold=1.0, mode=0):
        c = torch.nn.AvgPool1d(8, 8).cuda().half()
        internal_result = c(input_map)
        if (mode == 0):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 1):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        elif (mode == 2):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 3):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        return input_MP, internal_map

    def SNN_Flatten(self, input_map):
        c = torch.nn.Flatten().cuda().half()
        return c(input_map)

    def SNN_Linear(self, in_len, out_len, input_map, input_MP, weight, threhold=1.0, mode=0):
        c = torch.nn.Linear(in_features=in_len, out_features=out_len, bias=False)
        c.weight.data = weight
        # print(weight.shape, input_map.shape)
        internal_result = c(input_map)
        if (mode == 0):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 1):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        elif (mode == 2):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 3):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        return input_MP, internal_map

    def Leak_LIF(self, Input_MP, beta_1, beta_2):
        beta_1 = np.array([beta_1])
        beta_2 = np.array([beta_2])
        beta_1 = torch.from_numpy(beta_1).cuda().half()
        beta_2 = torch.from_numpy(beta_2).cuda().half()
        F_X = (Input_MP - Input_MP / (2 ** beta_1)) / 16
        Euler_1 = Input_MP - F_X * 2
        Euler_2 = (Euler_1 - Euler_1 / (2 ** beta_2)) / 8
        F_Y = Euler_2 / 2

        Input_MP = Input_MP - F_X - F_Y
        return Input_MP

    def Leak_LIF_New(self, Input_MP, beta_1, beta_2, beta_3):
        # beta_1 = np.array([beta_1])
        # beta_2 = np.array([beta_2])
        # beta_3 = np.array([beta_3])
        # beta_1 = torch.from_numpy(beta_1).cuda().half()
        # beta_2 = torch.from_numpy(beta_2).cuda().half()
        # beta_3 = torch.from_numpy(beta_3).cuda().half()
        #
        # F_X = (Input_MP - Input_MP / (2**beta_1)) / (2**beta_3) / 2
        # Euler_1 = Input_MP - F_X * 2
        # Euler_2 = (Euler_1 - Euler_1 / (2**beta_2)) / (2**beta_3)
        # F_Y = Euler_2 / 2
        # #
        # Input_MP = Input_MP - F_X - F_Y

        Input_MP = Input_MP
        return Input_MP


def Get_Accuracy_CNN_6(Test_Num, threhold=np.ones(7), mode=0, code_mode=0, attention=0,
                       beta_1=1.0, beta_2=0.0, beta_3=10.0):
    threhold = torch.from_numpy(np.array(threhold))
    threhold = threhold.cuda().half()

    current_directory = os.getcwd()
    pth_path    = os.path.join(current_directory, 'weight', 'view1.conv.0.weight.npy')
    pth_path_1  = os.path.join(current_directory, 'weight', 'view1.conv.4.weight.npy')
    pth_path_2  = os.path.join(current_directory, 'weight', 'view2.conv.1.weight.npy')
    pth_path_3  = os.path.join(current_directory, 'weight', 'view2.conv.5.weight.npy')
    pth_path_4  = os.path.join(current_directory, 'weight', 'view3.conv.1.weight.npy')
    pth_path_5  = os.path.join(current_directory, 'weight', 'view3.conv.5.weight.npy')
    pth_path_6  = os.path.join(current_directory, 'weight', 'fc.0.weight.npy')
    pth_path_7  = os.path.join(current_directory, 'weight', 'fc.2.weight.npy')
    pth_path_8  = os.path.join(current_directory, 'weight', 'attention.fc.weight.npy')
    pth_path_9  = os.path.join(current_directory, 'weight', 'attention.fc1.0.weight.npy')
    pth_path_10 = os.path.join(current_directory, 'weight', 'attention.fc2.0.weight.npy')
    pth_path_11 = os.path.join(current_directory, 'weight', 'attention.fc3.0.weight.npy')
    pth_path_12 = os.path.join(current_directory, 'weight', 'weight_1.npy')
    pth_path_13 = os.path.join(current_directory, 'weight', 'weight_2.npy')
    pth_path_14 = os.path.join(current_directory, 'weight', 'weight_3.npy')
    pth_path_15 = os.path.join(current_directory, 'weight', 'fused_output_np.npy')
    pth_path_16 = os.path.join(current_directory, 'weight', 'out1_np.npy')
    pth_path_17 = os.path.join(current_directory, 'weight', 'fea_a_np.npy')

    view1_ConV1_Weight = torch.from_numpy(
        np.load(pth_path).astype(
            'float16')).cuda().half()
    view1_ConV2_Weight = torch.from_numpy(
        np.load(pth_path_1).astype(
            'float16')).cuda().half()
    view2_ConV1_Weight = torch.from_numpy(
        np.load(pth_path_2).astype(
            'float16')).cuda().half()
    view2_ConV2_Weight = torch.from_numpy(
        np.load(pth_path_3).astype(
            'float16')).cuda().half()
    view3_ConV1_Weight = torch.from_numpy(
        np.load(pth_path_4).astype(
            'float16')).cuda().half()
    view3_ConV2_Weight = torch.from_numpy(
        np.load(pth_path_5).astype(
            'float16')).cuda().half()
    FC1_Weight = torch.from_numpy(
        np.load(pth_path_6).astype(
            'float16')).cuda().half()
    FC2_Weight = torch.from_numpy(
        np.load(pth_path_7).astype(
            'float16')).cuda().half()
    attention_weight = torch.from_numpy(
        np.load(pth_path_8).astype(
            'float16')).cuda().half()
    attention_fc1 = torch.from_numpy(
        np.load(pth_path_9).astype(
            'float16')).cuda().half()
    attention_fc2 = torch.from_numpy(
        np.load(pth_path_10).astype(
            'float16')).cuda().half()
    attention_fc3 = torch.from_numpy(
        np.load(pth_path_11).astype(
            'float16')).cuda().half()
    weight_1 = torch.from_numpy(
        np.load(pth_path_12).astype(
            'float16')).cuda().half()
    weight_2 = torch.from_numpy(
        np.load(pth_path_13).astype(
            'float16')).cuda().half()
    weight_3 = torch.from_numpy(
        np.load(pth_path_14).astype(
            'float16')).cuda().half()

    out1_np = np.load(pth_path_16).astype('float16')
    fused_output_np = np.load(pth_path_15).astype('float16')
    fea_a = np.load(pth_path_17).astype('float16')

    # 读取 .mat 文件
    current_directory = os.getcwd()
    mat_path = os.path.join(current_directory, 'data', '8anti_mat', 'new_all_DB08828.mat')
    mat_data = scipy.io.loadmat(mat_path)
    morgan = mat_data['morgan']
    enzyme = mat_data['enzyme']
    target = mat_data['target']
    pathway = mat_data['pathway']
    gnd = np.squeeze(mat_data['gnd'])

    morgan_drug_a_np = morgan[:1926, :2049]
    morgan_drug_b_np = morgan[:1926, 2049:]

    morgan_drug_a = torch.tensor(morgan[:1926, :2048])
    morgan_drug_b = torch.tensor(morgan[:1926, 2049:4097])

    target_drug_a = torch.tensor(target[:1926, :2261])
    target_drug_b = torch.tensor(target[:1926, 2261:])

    pathway_drug_a = torch.tensor(pathway[:1926, :2186])
    pathway_drug_b = torch.tensor(pathway[:1926, 2186:])

    max_gnd = max(np.unique(gnd))
    gnd_unique = np.unique(gnd)
    num_classes = len(gnd_unique)
    replace_dict = {old_value: new_value for new_value, old_value in enumerate(gnd_unique)}
    replace_func = np.vectorize(replace_dict.get)
    new_gnd = replace_func(gnd)
    # 制作数据集
    y_test = torch.tensor(new_gnd)



    true_image = 0
    batch_size = 756
    for image_index in range(int(Test_Num/batch_size)):

        spike_array_morgan_drug_a = torch.zeros((batch_size, 1, 2048)).cuda().half()

        spike_array_morgan_drug_b = torch.zeros((batch_size, 1, 2048)).cuda().half()
        #####################################################################################################

        ######################################################################################################
        ConV_1_MP_morgan_drug_a = torch.zeros((batch_size, 16, 2048)).cuda()
        Pooling_1_MP_morgan_drug_a = torch.zeros((batch_size, 16, 256)).cuda()

        ConV_1_MP_morgan_drug_b = torch.zeros((batch_size, 16, 2048)).cuda()
        Pooling_1_MP_morgan_drug_b = torch.zeros((batch_size, 16, 256)).cuda()
        ################################################################################

        ConV_2_MP_morgan_drug_a = torch.zeros((batch_size, 16, 256)).cuda()
        Pooling_2_MP_morgan_drug_a = torch.zeros((batch_size, 16, 32)).cuda()

        ConV_2_MP_morgan_drug_b = torch.zeros((batch_size, 16, 256)).cuda()
        Pooling_2_MP_morgan_drug_b = torch.zeros((batch_size, 16, 32)).cuda()

        ###################################################################################################


        view1_FC_MP_Memory = torch.zeros((batch_size, 512)).cuda()
        view2_FC_MP_Memory = torch.zeros((batch_size, 512)).cuda()
        view3_FC_MP_Memory = torch.zeros((batch_size, 512)).cuda()
        FC1_MP_Memory = torch.zeros((batch_size, 256)).cuda().half()
        FC2_MP_Memory = torch.zeros((batch_size, num_classes)).cuda().half()
        Spiking_NN = SNN_In_Pytorch()

        Dense_Result = torch.zeros((batch_size,num_classes)).cuda()


        start_time = time.time()

        for time_stemp in range(1):

            for batch_num in range(batch_size):
                spike_array_morgan_drug_a[batch_num] = morgan_drug_a[image_index * batch_size + batch_num]
                spike_array_morgan_drug_b[batch_num] = morgan_drug_b[image_index * batch_size + batch_num]

            if(code_mode==0):

                ######################################################################################################################################################
                ConV_1_MP_morgan_drug_a, ConV1_Output_Map_morgan_drug_a = Spiking_NN.SNN_ConV(in_channels=1, out_channels=16, stride=1, padding=1,
                                                                  input_map=spike_array_morgan_drug_a,
                                                                  weight=view1_ConV1_Weight,input_MP=ConV_1_MP_morgan_drug_a,threhold=threhold[0],mode=mode)
                ConV_1_MP_morgan_drug_a = Spiking_NN.Leak_LIF_New(ConV_1_MP_morgan_drug_a,beta_1=beta_1,beta_2=beta_2,beta_3=beta_3)

                ConV_1_MP_morgan_drug_b, ConV1_Output_Map_morgan_drug_b = Spiking_NN.SNN_ConV(in_channels=1,
                                                                                              out_channels=16, stride=1,
                                                                                              padding=1,
                                                                                              input_map=spike_array_morgan_drug_b,
                                                                                              weight=view1_ConV1_Weight,
                                                                                              input_MP=ConV_1_MP_morgan_drug_b,
                                                                                              threhold=threhold[0],
                                                                                              mode=mode)
                ConV_1_MP_morgan_drug_b = Spiking_NN.Leak_LIF_New(ConV_1_MP_morgan_drug_b, beta_1=beta_1, beta_2=beta_2,
                                                                  beta_3=beta_3)
            ######################################################################################################################################################
            Pooling_1_MP_morgan_drug_a, Pooling_1_Output_Map_morgan_drug_a = Spiking_NN.SNN_Average_Pooling(input_map=ConV1_Output_Map_morgan_drug_a,
                                                                                input_MP=Pooling_1_MP_morgan_drug_a,threhold=threhold[1],mode=mode)

            Pooling_1_MP_morgan_drug_b, Pooling_1_Output_Map_morgan_drug_b = Spiking_NN.SNN_Average_Pooling(
                input_map=ConV1_Output_Map_morgan_drug_b,
                input_MP=Pooling_1_MP_morgan_drug_b, threhold=threhold[1], mode=mode)
            ######################################################################################################################################################

            ConV_2_MP_morgan_drug_a, ConV2_Output_Map_morgan_drug_a = Spiking_NN.SNN_ConV(in_channels=16,
                                                                                          out_channels=16, stride=1,
                                                                                          padding=1,
                                                                                          input_map=Pooling_1_Output_Map_morgan_drug_a,
                                                                                          weight=view1_ConV2_Weight,
                                                                                          input_MP=ConV_2_MP_morgan_drug_a,
                                                                                          threhold=threhold[0],
                                                                                          mode=mode)
            ConV_2_MP_morgan_drug_a = Spiking_NN.Leak_LIF_New(ConV_2_MP_morgan_drug_a, beta_1=beta_1, beta_2=beta_2,
                                                              beta_3=beta_3)

            ConV_2_MP_morgan_drug_b, ConV2_Output_Map_morgan_drug_b = Spiking_NN.SNN_ConV(in_channels=16,
                                                                                          out_channels=16, stride=1,
                                                                                          padding=1,
                                                                                          input_map=Pooling_1_Output_Map_morgan_drug_b,
                                                                                          weight=view1_ConV2_Weight,
                                                                                          input_MP=ConV_2_MP_morgan_drug_b,
                                                                                          threhold=threhold[0],
                                                                                          mode=mode)
            ConV_2_MP_morgan_drug_b = Spiking_NN.Leak_LIF_New(ConV_2_MP_morgan_drug_b, beta_1=beta_1, beta_2=beta_2,
                                                              beta_3=beta_3)
            ######################################################################################################################################################

            Pooling_2_MP_morgan_drug_a, Pooling_2_Output_Map_morgan_drug_a = Spiking_NN.SNN_Average_Pooling(
                input_map=ConV2_Output_Map_morgan_drug_a,
                input_MP=Pooling_2_MP_morgan_drug_a, threhold=threhold[1], mode=mode)

            Pooling_2_MP_morgan_drug_b, Pooling_2_Output_Map_morgan_drug_b = Spiking_NN.SNN_Average_Pooling(
                input_map=ConV2_Output_Map_morgan_drug_b,
                input_MP=Pooling_2_MP_morgan_drug_b, threhold=threhold[1], mode=mode)
            ######################################################################################################################################################
            view1_a_temp = Spiking_NN.SNN_Flatten(input_map=Pooling_2_Output_Map_morgan_drug_a)
            view1_b_temp = Spiking_NN.SNN_Flatten(input_map=Pooling_2_Output_Map_morgan_drug_b)
            merged_feat_1 = torch.cat((view1_a_temp, view1_b_temp), dim=1)


            # view1_a_temp  = view1_a_temp.cpu().numpy()
            # view1_b_temp = view1_b_temp.cpu().numpy()
            #
            #
            # are_equal = np.array_equal(fea_a, view1_b_temp)
            # differences = fea_a != view1_b_temp
            # num_differences = np.sum(differences)
            ######################################################################################################################################################
            view1_FC_MP_Memory, view1_FC_Output_Map = Spiking_NN.SNN_Linear(in_len=1024,out_len=512,input_map=merged_feat_1, input_MP=view1_FC_MP_Memory,
                                                                 weight=attention_fc1,threhold=threhold[4],mode=mode)



            view1_FC_Output_Map_np = view1_FC_Output_Map.cpu().numpy()
            are_equal = np.array_equal(out1_np, view1_FC_Output_Map_np)
            differences = out1_np != view1_FC_Output_Map_np
            num_differences = np.sum(differences)
            FC1_MP_Memory, FC1_Output_Map = Spiking_NN.SNN_Linear(in_len=1024, out_len=256, input_map= merged_feat_1,
                                                                  input_MP=FC1_MP_Memory,
                                                                  weight=FC1_Weight, threhold=threhold[4], mode=mode)
            # FC1_MP_Memory = Spiking_NN.Leak_LIF_New(FC1_MP_Memory, beta_1=beta_1, beta_2=beta_2, beta_3=beta_3)

            FC2_MP_Memory, FC2_Output_Map = Spiking_NN.SNN_Linear(in_len=256, out_len=num_classes, input_map=FC1_Output_Map,
                                                                  input_MP=FC2_MP_Memory,
                                                                  weight=FC2_Weight, threhold=threhold[5], mode=mode)
            # FC2_MP_Memory = Spiking_NN.Leak_LIF_New(FC2_MP_Memory, beta_1=beta_1, beta_2=beta_2, beta_3=beta_3)

            Dense_Result[torch.where(FC2_Output_Map == 1)] += 1
            if Dense_Result.is_cuda:
                Dense_Result_np = Dense_Result.cpu()
            Dense_Result_np = Dense_Result_np.numpy()

        for i in range(batch_size):
            if torch.argmax(Dense_Result[i]) == y_test[image_index * batch_size + i]:
                true_image += 1
        print(time.time()-start_time)
        print(image_index, 'True_Image:{0}/{1}'.format(true_image, (image_index+1) * batch_size))
    return true_image/batch_size



if __name__ == '__main__':
    threholden = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]
    a = Get_Accuracy_CNN_6(Test_Num=1296, threhold = threholden, mode=2, code_mode=0, attention=1)
    print(a)
