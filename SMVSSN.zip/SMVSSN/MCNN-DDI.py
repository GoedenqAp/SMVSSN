import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
from sklearn.metrics import accuracy_score, average_precision_score
from tqdm import tqdm



class Config:
    num_drugs = 1000
    num_features = 4
    num_classes = 19
    batch_size = 32
    epochs = 20
    lr = 0.001
    input_size = 100
    hidden_dim = 256
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")



class DDIDataset(Dataset):
    def __init__(self, num_samples=1000):
        self.num_samples = num_samples

        self.features = [torch.rand(num_samples, Config.input_size, Config.input_size) for _ in
                         range(Config.num_features)]
        self.labels = torch.randint(0, Config.num_classes, (num_samples,))

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        return [feature[idx] for feature in self.features], self.labels[idx]


# 子CNN模块
class SubCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 8, kernel_size=3, padding=1),
            nn.Tanh(),
            nn.MaxPool2d(2),  # 50x50
            nn.Conv2d(8, 16, kernel_size=3, padding=1),
            nn.ELU(),
            nn.MaxPool2d(2)  # 25x25
        )
        self.fc = nn.Sequential(
            nn.Linear(16 * 25 * 25, Config.hidden_dim),
            nn.BatchNorm1d(Config.hidden_dim),
            nn.Dropout(0.3)
        )

    def forward(self, x):
        x = x.unsqueeze(1)
        x = self.conv(x)
        x = x.view(x.size(0), -1)
        return self.fc(x)



class MCNN_DDI(nn.Module):
    def __init__(self):
        super().__init__()
        self.subnets = nn.ModuleList([SubCNN() for _ in range(Config.num_features)])
        self.classifier = nn.Sequential(
            nn.Linear(Config.hidden_dim * Config.num_features, 512),
            nn.ELU(),
            nn.BatchNorm1d(512),
            nn.Dropout(0.3),
            nn.Linear(512, Config.num_classes)
        )

    def forward(self, features):
        embeddings = []
        for i in range(Config.num_features):
            emb = self.subnets[i](features[i])
            embeddings.append(emb)
        x = torch.cat(embeddings, dim=1)
        return self.classifier(x)



def train(model, dataloader, criterion, optimizer):
    model.train()
    total_loss = 0
    preds, truths = [], []

    for features, labels in tqdm(dataloader, desc="Training"):
        features = [f.float().to(Config.device) for f in features]
        labels = labels.long().to(Config.device)

        optimizer.zero_grad()
        outputs = model(features)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        preds.extend(torch.argmax(outputs, 1).cpu().numpy())
        truths.extend(labels.cpu().numpy())

    acc = accuracy_score(truths, preds)
    return total_loss / len(dataloader), acc



def evaluate(model, dataloader, criterion):
    model.eval()
    total_loss = 0
    preds, truths, probs = [], [], []

    with torch.no_grad():
        for features, labels in tqdm(dataloader, desc="Evaluating"):
            features = [f.float().to(Config.device) for f in features]
            labels = labels.long().to(Config.device)

            outputs = model(features)
            loss = criterion(outputs, labels)

            total_loss += loss.item()
            preds.extend(torch.argmax(outputs, 1).cpu().numpy())
            truths.extend(labels.cpu().numpy())
            probs.extend(torch.softmax(outputs, 1).cpu().numpy())

    acc = accuracy_score(truths, preds)
    aupr = average_precision_score(truths, probs, average="macro", multi_class="ovr")
    return total_loss / len(dataloader), acc, aupr


def main():

    train_dataset = DDIDataset(num_samples=2000)
    test_dataset = DDIDataset(num_samples=500)

    train_loader = DataLoader(train_dataset, batch_size=Config.batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=Config.batch_size)


    model = MCNN_DDI().to(Config.device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=Config.lr)


    best_aupr = 0
    for epoch in range(Config.epochs):
        train_loss, train_acc = train(model, train_loader, criterion, optimizer)
        val_loss, val_acc, val_aupr = evaluate(model, test_loader, criterion)

        print(f"Epoch {epoch + 1}/{Config.epochs}")
        print(f"Train Loss: {train_loss:.4f} | Acc: {train_acc:.4f}")
        print(f"Val Loss: {val_loss:.4f} | Acc: {val_acc:.4f} | AUPR: {val_aupr:.4f}")


        if val_aupr > best_aupr:
            best_aupr = val_aupr
            torch.save(model.state_dict(), "best_model.pth")


    model.load_state_dict(torch.load("best_model.pth"))
    test_loss, test_acc, test_aupr = evaluate(model, test_loader, criterion)
    print("\nFinal Test Results:")
    print(f"Accuracy: {test_acc:.4f} | AUPR: {test_aupr:.4f}")


if __name__ == "__main__":
    main()