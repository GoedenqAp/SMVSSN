import torch
import numpy as np
import os
current_directory = os.getcwd()
pth_path = os.path.join(current_directory, 'logs', 'Single_DB08828.pth')
content = torch.load(pth_path)

for k, v in content.items():
    a = v.cpu().numpy()
    if k[-6:] == 'weight':
        npy_path = os.path.join(current_directory, 'weight', '{}.npy')
        np.save(npy_path.format(k), a)
print(content.keys())


