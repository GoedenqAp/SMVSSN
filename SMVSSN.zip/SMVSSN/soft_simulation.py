import torch
import numpy as np
import time
import os
#os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
from sklearn.datasets import fetch_lfw_people
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
from skimage.transform import resize
from torch.utils.data import DataLoader, Dataset, random_split
import os
import scipy
import pandas as pd

class MyDataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sample = self.data[idx]
        label = self.labels[idx]
        return sample, label
# from Gpu_GA_Code.Batch_CNNSpiking_In_Pytorch_CNN_5 import SNN_In_Pytorch
class LFWDataset(Dataset):
    def __init__(self, images, labels, transform=None):
        self.images = images
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        image = self.images[idx]
        label = self.labels[idx]

        if self.transform:
            image = self.transform(image)

        return image, label


def bin2dec(b):
    d = 0
    for i, x in enumerate(b):
        d += 2 ** (-i - 1) * x
    return d


def generate_rand(seed):
    temp_seed = seed[1:] + [seed[0]]

    temp_seed[-2] = seed[0] ^ seed[-1]
    temp_seed[-3] = seed[0] ^ seed[-2]
    temp_seed[-5] = seed[0] ^ seed[-4]
    temp_seed[-8] = seed[0] ^ seed[-7]
    temp_seed[-10] = seed[0] ^ seed[-9]
    temp_seed[-12] = seed[0] ^ seed[-11]

    seed = temp_seed

    return seed, bin2dec(seed)


def int2bin(x):
    return '{0:08b}'.format(x) + '0' * 4


def coding(pixel, seed):
    seed, x = generate_rand(seed)
    # x = np.random.rand()
    # print(pixel,x)
    temp = int2bin(pixel)

    a = [int(temp[i]) for i in range(len(temp))]
    aa = bin2dec(a)
    if (x < aa):
        spike = 1
    else:
        spike = 0
    return spike, seed


class SNN_In_Pytorch():
    def __init__(self):
        pass

    def sa(self, x, padding, weight):
        conv = torch.nn.Conv2d(2, 1, 7, padding=padding, bias=False).cuda().half()
        sigmoid = torch.nn.Sigmoid()
        conv.weight.data = weight
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        y = torch.cat([avg_out, max_out], dim=1)
        y = conv(y)
        return sigmoid(y) * x

    def sa_conv(self, in_channels, out_channels, stride, padding, x, weight, input_MP, threhold=1.0):
        c = torch.nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=7, stride=stride,
                            padding=padding, bias=False).cuda().half()
        # sigmoid =torch.nn.Sigmoid()
        c.weight.data = weight
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        internal_map = torch.cat([avg_out, max_out], dim=1)
        internal_result = c(internal_map)
        # print(out_channels,internal_result.shape,input_MP.shape)
        input_MP += internal_result
        internal_map = torch.zeros(internal_result.shape).cuda().half()
        internal_map[torch.where(input_MP >= threhold)] = 1
        input_MP[torch.where(input_MP >= threhold)] = 0
        internal_map = internal_map * x
        return input_MP, internal_map

    def code(self, in_channels, out_channels, stride, padding, input_map, input_MP, threhold=1.0, mode=0):
        input_MP += input_map
        internal_map = torch.zeros(input_map.shape).cuda().half()
        internal_map[torch.where(input_MP >= threhold)] = 1
        input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        return input_MP, internal_map

    def SNN_ConV(self, in_channels, out_channels, stride, padding, input_map, weight, input_MP, threhold=1.0, mode=0):
        c = torch.nn.Conv1d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, stride=stride,
                            padding=padding, bias=False).cuda().half()
        c.weight.data = weight
        internal_result = c(input_map)
        # input_MP += internal_result
        if (mode == 0):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 1):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        elif (mode == 2):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 3):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        return input_MP, internal_map

    def SNN_Average_Pooling(self, input_map, input_MP, threhold=1.0, mode=0):
        c = torch.nn.AvgPool1d(8, 8).cuda().half()
        internal_result = c(input_map)
        if (mode == 0):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 1):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        elif (mode == 2):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 3):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        return input_MP, internal_map

    def SNN_Flatten(self, input_map):
        c = torch.nn.Flatten().cuda().half()
        return c(input_map)

    def SNN_Linear(self, in_len, out_len, input_map, input_MP, weight, threhold=1.0, mode=0):
        c = torch.nn.Linear(in_features=in_len, out_features=out_len, bias=False)
        c.weight.data = weight
        # print(weight.shape, input_map.shape)
        internal_result = c(input_map)
        if (mode == 0):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 1):
            input_MP += internal_result
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        elif (mode == 2):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = input_MP[torch.where(input_MP >= threhold)] - threhold
        elif (mode == 3):
            input_MP = internal_result + (input_MP) / 2.0
            internal_map = torch.zeros(internal_result.shape).cuda().half()
            internal_map[torch.where(input_MP >= threhold)] = 1
            input_MP[torch.where(input_MP >= threhold)] = 0
        return input_MP, internal_map

    def Leak_LIF(self, Input_MP, beta_1, beta_2):
        beta_1 = np.array([beta_1])
        beta_2 = np.array([beta_2])
        beta_1 = torch.from_numpy(beta_1).cuda().half()
        beta_2 = torch.from_numpy(beta_2).cuda().half()
        F_X = (Input_MP - Input_MP / (2 ** beta_1)) / 16
        Euler_1 = Input_MP - F_X * 2
        Euler_2 = (Euler_1 - Euler_1 / (2 ** beta_2)) / 8
        F_Y = Euler_2 / 2

        Input_MP = Input_MP - F_X - F_Y
        return Input_MP

    def Leak_LIF_New(self, Input_MP, beta_1, beta_2, beta_3):
        # beta_1 = np.array([beta_1])
        # beta_2 = np.array([beta_2])
        # beta_3 = np.array([beta_3])
        # beta_1 = torch.from_numpy(beta_1).cuda().half()
        # beta_2 = torch.from_numpy(beta_2).cuda().half()
        # beta_3 = torch.from_numpy(beta_3).cuda().half()
        #
        # F_X = (Input_MP - Input_MP / (2**beta_1)) / (2**beta_3) / 2
        # Euler_1 = Input_MP - F_X * 2
        # Euler_2 = (Euler_1 - Euler_1 / (2**beta_2)) / (2**beta_3)
        # F_Y = Euler_2 / 2
        # #
        # Input_MP = Input_MP - F_X - F_Y

        Input_MP = Input_MP
        return Input_MP


def Get_Accuracy_CNN_6(Test_Num, threhold=np.ones(7), TestDataset='Fashion-MNIST', mode=0, code_mode=0, attention=0,
                       beta_1=1.0, beta_2=0.0, beta_3=10.0):
    threhold = torch.from_numpy(np.array(threhold))
    threhold = threhold.cuda().half()


    if TestDataset == 'YaleB':
        current_directory = os.getcwd()
        pth_path = os.path.join(current_directory, 'ANN_2_SNN', 'conv.1.weight.npy')
        pth_path_1 = os.path.join(current_directory, 'ANN_2_SNN', 'conv.5.weight.npy')
        pth_path_2 = os.path.join(current_directory, 'ANN_2_SNN', 'fc.1.weight.npy')
        pth_path_3 = os.path.join(current_directory, 'ANN_2_SNN', 'fc.3.weight.npy')
        ConV1_Weight = torch.from_numpy(
            np.load(pth_path).astype(
                'float16')).cuda().half()
        ConV2_Weight = torch.from_numpy(
            np.load(pth_path_1).astype(
                'float16')).cuda().half()
        FC1_Weight = torch.from_numpy(
            np.load(pth_path_2).astype(
                'float16')).cuda().half()
        FC2_Weight = torch.from_numpy(
            np.load(pth_path_3).astype(
                'float16')).cuda().half()

        y_test = np.array(
            pd.read_csv(os.path.join(current_directory, 'shuffled_data_labels.csv'), header=None).iloc[:, 1].values)
        y_test = torch.from_numpy(
            (y_test).astype('float16')).cuda().half()
        x_test = os.path.join(current_directory, 'output_npy_files')

    elif TestDataset == 'DDI':
        current_directory = os.getcwd()
        pth_path = os.path.join(current_directory, 'weight', 'conv.1.weight.npy')
        pth_path_1 = os.path.join(current_directory, 'weight', 'conv.5.weight.npy')
        pth_path_2 = os.path.join(current_directory, 'weight', 'fc.1.weight.npy')
        pth_path_3 = os.path.join(current_directory, 'weight', 'fc.3.weight.npy')
        ConV1_Weight = torch.from_numpy(
            np.load(pth_path).astype(
                'float16')).cuda().half()
        ConV2_Weight = torch.from_numpy(
            np.load(pth_path_1).astype(
                'float16')).cuda().half()
        FC1_Weight = torch.from_numpy(
            np.load(pth_path_2).astype(
                'float16')).cuda().half()
        FC2_Weight = torch.from_numpy(
            np.load(pth_path_3).astype(
                'float16')).cuda().half()

        # 读取 .mat 文件
        current_directory = os.getcwd()
        mat_path = os.path.join(current_directory, 'data', '8anti_mat', 'new_all_DB00317.mat')
        mat_data = scipy.io.loadmat(mat_path)
        morgan = mat_data['morgan']
        enzyme = mat_data['enzyme']
        target = mat_data['target']
        pathway = mat_data['pathway']
        gnd = np.squeeze(mat_data['gnd'])

        x_test = torch.tensor(morgan).unsqueeze(1)
        y_test = torch.tensor(gnd)



    true_image = 0
    batch_size = 32
    for image_index in range(int(Test_Num/batch_size)):

        spike_array = torch.zeros((batch_size, 1, 4098)).cuda().half()
        code_MP = torch.zeros((batch_size, 1, 4098)).cuda()

        ConV_1_MP = torch.zeros((batch_size,16,4098)).cuda()
        Pooling_1_MP = torch.zeros((batch_size, 16, 512)).cuda()

        ConV_2_MP = torch.zeros((batch_size,16,512)).cuda()
        Pooling_2_MP = torch.zeros((batch_size,16,64)).cuda()

        FC1_MP_Memory = torch.zeros((batch_size,256)).cuda()
        FC2_MP_Memory = torch.zeros((batch_size,36)).cuda()
        Spiking_NN = SNN_In_Pytorch()

        Dense_Result = torch.zeros((batch_size,36)).cuda()


        start_time = time.time()

        for time_stemp in range(10):

            for batch_num in range(batch_size):
                spike_array[batch_num] = x_test[image_index * batch_size + batch_num]
            if(code_mode==0):

                code_MP, code_Output_Map = Spiking_NN.code(in_channels=1, out_channels=1, stride=1, padding=1,
                                                                  input_map=spike_array,
                                                                  input_MP=code_MP,threhold=1.0,mode=mode)

                ConV_1_MP, ConV1_Output_Map = Spiking_NN.SNN_ConV(in_channels=1, out_channels=16, stride=1, padding=1,
                                                                  input_map=code_Output_Map,
                                                                  weight=ConV1_Weight,input_MP=ConV_1_MP,threhold=threhold[0],mode=mode)
                ConV_1_MP = Spiking_NN.Leak_LIF_New(ConV_1_MP,beta_1=beta_1,beta_2=beta_2,beta_3=beta_3)
            elif(code_mode==1):
                for batch_num in range(batch_size):
                    spike_array[batch_num] = x_test[image_index * batch_size + batch_num]

                ConV_1_MP, ConV1_Output_Map = Spiking_NN.SNN_ConV(in_channels=1, out_channels=32, stride=1, padding=1,
                                                                  input_map=spike_array,
                                                                  weight=ConV1_Weight,input_MP=ConV_1_MP,threhold=threhold[0],mode=mode)
                # ConV_1_MP = Spiking_NN.Leak_LIF_New(ConV_1_MP,beta_1=beta_1,beta_2=beta_2,beta_3=beta_3)

            Pooling_1_MP, Pooling_1_Output_Map = Spiking_NN.SNN_Average_Pooling(input_map=ConV1_Output_Map,
                                                                                input_MP=Pooling_1_MP,threhold=threhold[1],mode=mode)
            # Pooling_1_MP = Spiking_NN.Leak_LIF_New(Pooling_1_MP,beta_1=beta_1, beta_2=beta_2, beta_3=beta_3)

            ConV_2_MP, ConV2_Output_Map = Spiking_NN.SNN_ConV(in_channels=16, out_channels=16, stride=1, padding=1,
                                                              input_map=Pooling_1_Output_Map,
                                                              weight=ConV2_Weight,
                                                              input_MP=ConV_2_MP,threhold=threhold[2],mode=mode)
            # ConV_2_MP = Spiking_NN.Leak_LIF_New(ConV_2_MP,beta_1=beta_1, beta_2=beta_2, beta_3=beta_3)

            Pooling_2_MP,Pooling_2_Output_Map = Spiking_NN.SNN_Average_Pooling(input_map=ConV2_Output_Map,input_MP=Pooling_2_MP,threhold=threhold[3],mode=mode)
            # Pooling_2_MP = Spiking_NN.Leak_LIF_New(Pooling_2_MP,beta_1=beta_1, beta_2=beta_2, beta_3=beta_3)

            FC_Input = Spiking_NN.SNN_Flatten(input_map=Pooling_2_Output_Map)

            FC1_MP_Memory,FC1_Output_Map = Spiking_NN.SNN_Linear(in_len=1024,out_len=256,input_map=FC_Input,input_MP=FC1_MP_Memory,
                                                                 weight=FC1_Weight,threhold=threhold[4],mode=mode)
            # FC1_MP_Memory = Spiking_NN.Leak_LIF_New(FC1_MP_Memory, beta_1=beta_1, beta_2=beta_2, beta_3=beta_3)

            FC2_MP_Memory,FC2_Output_Map = Spiking_NN.SNN_Linear(in_len=256,out_len=36,input_map=FC1_Output_Map,input_MP=FC2_MP_Memory,
                                                                 weight=FC2_Weight,threhold=threhold[5],mode=mode)
            # FC2_MP_Memory = Spiking_NN.Leak_LIF_New(FC2_MP_Memory, beta_1=beta_1, beta_2=beta_2, beta_3=beta_3)

            Dense_Result[torch.where(FC2_Output_Map == 1)] += 1
            if Dense_Result.is_cuda:
                Dense_Result_np = Dense_Result.cpu()
            Dense_Result_np = Dense_Result_np.numpy()

        for i in range(batch_size):
            if torch.argmax(Dense_Result[i]) == y_test[image_index * batch_size + i]:
                true_image += 1
        print(time.time()-start_time)
        print(image_index, 'True_Image:{0}/{1}'.format(true_image, (image_index+1) * batch_size))
    return true_image/Test_Num



if __name__ == '__main__':
    threholden = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]
    a = Get_Accuracy_CNN_6(Test_Num=1296, threhold = threholden, TestDataset='DDI', mode=2, code_mode=0, attention=1)
    print(a)
