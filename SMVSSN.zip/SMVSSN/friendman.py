import numpy as np
from scipy.stats import friedmanchisquare


group1 = np.array([0.814,	0.701,	0.928,	0.825,	0.729,	0.621,	0.823,	0.723
])
group2 = np.array([0.785,	0.675,	0.889,	0.784,	0.688,	0.612,	0.785,	0.661
])
group3 = np.array([0.8,	0.707,	0.924,	0.811,	0.729,	0.596,	0.824,	0.724
])
group4 = np.array([0.78,	0.696,	0.916,	0.807,	0.729,	0.625,	0.806,	0.756

])
group5 = np.array([0.877,	0.766,	0.902,	0.885,	0.937,	0.85,	0.901,	0.903

])
group6 = np.array([0.898,	0.914,	0.945,	0.88,	0.928,	0.902,	0.895,	0.968

])
group7 = np.array([0.937,	0.941,	0.951,	0.895,	0.907,	0.915,	0.939,	0.973

])
group8 = np.array([0.923,	0.933,	0.909,	0.932,	0.911,	0.928,	0.933,	0.971

])
group9 = np.array([0.942,	0.962,	0.977,	0.935,	0.994,	0.974,	0.969,	0.984

])


stat, p_value = friedmanchisquare(group1, group2, group3, group4, group5, group6, group7, group8, group9)

print(f"Friedman’s test statistic: {stat}")
print(f"p-value: {p_value}")


alpha = 0.05

