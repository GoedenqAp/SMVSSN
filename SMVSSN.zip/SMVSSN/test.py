import csv
import os


current_directory = os.getcwd()
input_file = os.path.join(current_directory, 'data', '43anti_extract_interaction.csv')
output_file = 'output.csv'


with open(input_file, 'r', newline='') as infile:
    reader = csv.reader(infile)


    with open(output_file, 'w', newline='') as outfile:
        writer = csv.writer(outfile)


        for row in reader:

            if "Ibrutinib" in row[0]:

                writer.writerow([row[0], row[1], row[4]])
