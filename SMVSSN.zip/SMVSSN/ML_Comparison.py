import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, accuracy_score, roc_curve, precision_score, f1_score, recall_score, auc, cohen_kappa_score
from sklearn.linear_model import LogisticRegression, ElasticNet
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
from scipy.stats import pearsonr
from sklearn.preprocessing import label_binarize
import scipy
import os
from sklearn.svm import SVC

# 读取 .mat 文件
current_directory = os.getcwd()
folder_path = os.path.join(current_directory, 'data', '8anti_mat')
mat_files = [f for f in os.listdir(folder_path) if f.endswith('.mat')]
for mat_file in mat_files:
    # 保存当前文件名到变量
    current_file_name = mat_file[-11:-4]
    # 构建完整文件路径
    file_path = os.path.join(folder_path, mat_file)

    # 读取 .mat 文件
    mat_data = scipy.io.loadmat(file_path)
    morgan = mat_data['morgan']
    enzyme = mat_data['enzyme']
    target = mat_data['target']
    pathway = mat_data['pathway']
    gnd = np.squeeze(mat_data['gnd'])

    morgan_drug_a = morgan[:1926, :2049]
    morgan_drug_b = morgan[:1926, 2049:]

    target_drug_a = target[:1926, :2261]
    target_drug_b = target[:1926, 2261:]

    pathway_drug_a = pathway[:1926, :2186]
    pathway_drug_b = pathway[:1926, 2186:]

    enzyme_drug_a = enzyme[:1926, :330]
    enzyme_drug_b = enzyme[:1926, 330:]

    gnd_unique = np.unique(gnd)
    replace_dict = {old_value: new_value for new_value, old_value in enumerate(gnd_unique)}
    replace_func = np.vectorize(replace_dict.get)
    new_gnd = replace_func(gnd)

    # 假设你有以下数据
    # X: 特征矩阵，y: 标签，针对多分类任务
    X = morgan  # 示例数据，1000个样本，20个特征
    y = new_gnd  # 示例标签，多分类任务，假设有3个类别

    # 将多分类标签进行二值化，用于计算AUC
    y_bin = label_binarize(y, classes = list(range(len(gnd_unique))))

    # 模型字典
    models = {
        'XGBoost': XGBClassifier(use_label_encoder=False, eval_metric='mlogloss'),
        'GradientBoosting': GradientBoostingClassifier(),
        'LogisticRegression': LogisticRegression(multi_class='multinomial', max_iter=1000),
        'RandomForest': RandomForestClassifier(),
        'SVM': SVC(probability=True)
    }

    # 设置5折交叉验证
    kf = KFold(n_splits=5, shuffle=True, random_state=42)

    # 初始化结果字典
    results = {model_name: {'RMSE': [], 'PCC': [], 'ACC': [], 'Precision': [], 'F1': [], 'Recall': [], 'AUC': [], 'Kappa': [], 'PREC': []}
               for model_name in models.keys()}

    # 交叉验证循环
    for train_idx, val_idx in kf.split(X):
        X_train, X_val = X[train_idx], X[val_idx]
        y_train, y_val = y[train_idx], y[val_idx]
        y_val_bin = y_bin[val_idx]

        for model_name, model in models.items():
            if model_name == 'ElasticNet':  # ElasticNet是回归模型，不适合多分类任务，跳过它
                continue

            model.fit(X_train, y_train)
            y_pred_class = model.predict(X_val)
            y_pred_proba = model.predict_proba(X_val) if hasattr(model, 'predict_proba') else model.decision_function(X_val)

            # 计算RMSE
            rmse = np.sqrt(mean_squared_error(y_val, y_pred_class))

            # 计算PCC
            pcc, _ = pearsonr(y_val, y_pred_class)

            # 计算其他指标
            acc = accuracy_score(y_val, y_pred_class)

            # 计算并绘制每个类别的ROC曲线
            fpr = dict()
            tpr = dict()
            roc_auc = dict()
            for i in range(y_pred_proba.shape[1]):
                fpr[i], tpr[i], _ = roc_curve(y_val_bin[:, i], y_pred_proba[:, i])
                roc_auc[i] = auc(fpr[i], tpr[i])
            values = [v for v in roc_auc.values() if not np.isnan(v)]
            mean_value = np.mean(values)
            Auc = mean_value

            precision = precision_score(y_val, y_pred_class, average='macro')
            f1 = f1_score(y_val, y_pred_class, average='macro')
            recall = recall_score(y_val, y_pred_class, average='macro')
            # 计算Cohen's Kappa
            kappa = cohen_kappa_score(y_val, y_pred_class)

            # 计算PREC (Positive Rate for Positive Predictions)
            prec = np.sum((y_pred_class == y_val) & (y_val > 0)) / np.sum(y_pred_class > 0)

            # 将结果保存到字典
            results[model_name]['RMSE'].append(rmse)
            results[model_name]['PCC'].append(pcc)
            results[model_name]['ACC'].append(acc)
            results[model_name]['Precision'].append(precision)
            results[model_name]['F1'].append(f1)
            results[model_name]['Recall'].append(recall)
            results[model_name]['AUC'].append(Auc)
            results[model_name]['Kappa'].append(kappa)
            results[model_name]['PREC'].append(prec)

    # 计算每个模型的平均值和标准误差，并保存到CSV文件
    final_results = []
    for model_name, metrics in results.items():
        row = {'Model': model_name}
        for metric_name, values in metrics.items():
            mean_value = np.mean(values)
            std_error = np.std(values)
            row[f'{metric_name}_mean'] = mean_value
            row[f'{metric_name}_std'] = std_error
        final_results.append(row)

    # 保存结果到CSV
    current_directory = os.getcwd()
    output_dir = os.path.join(current_directory, 'data', 'table')
    filename = current_file_name
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    output_path = os.path.join(output_dir, filename + '.csv')
    df = pd.DataFrame(final_results)
    df.to_csv(output_path, index=False)

    print("Results saved to 'cross_validation_results_multiclass.csv'")
