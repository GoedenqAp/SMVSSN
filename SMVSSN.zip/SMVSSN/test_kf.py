import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from spikingjelly.clock_driven import neuron, functional, surrogate, layer,encoding
from torch.utils.tensorboard import SummaryWriter
import os
import time
import argparse
import numpy as np
from scipy import interp
from torch.cuda import amp
import torchvision.transforms as transforms
from scipy.stats import pearsonr
from torch.utils.data import DataLoader, Dataset, random_split, Subset
from itertools import cycle
import csv
import os
from sklearn.model_selection import train_test_split
import scipy
from sklearn.model_selection import KFold
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, mean_squared_error, roc_curve, auc
from sklearn.metrics import cohen_kappa_score, matthews_corrcoef, r2_score
from sklearn.preprocessing import label_binarize
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
import warnings
# 抑制所有警告
warnings.filterwarnings("ignore")

class DrugInteractionDataset(Dataset):
    def __init__(self, morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, labels):
        self.morgan_drug_a = morgan_drug_a
        self.morgan_drug_b = morgan_drug_b

        self.target_drug_a = target_drug_a
        self.target_drug_b = target_drug_b

        self.pathway_drug_a = pathway_drug_a
        self.pathway_drug_b = pathway_drug_b

        self.labels = labels

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):

        view1_a = self.morgan_drug_a[idx]
        view1_a = torch.tensor(view1_a)
        view1_a = view1_a.unsqueeze(0)

        view1_b = self.morgan_drug_b[idx]
        view1_b = torch.tensor(view1_b)
        view1_b = view1_b.unsqueeze(0)

        view2_a = self.target_drug_a[idx]
        view2_a = torch.tensor(view2_a)
        view2_a = view2_a.unsqueeze(0)

        view2_b = self.target_drug_b[idx]
        view2_b = torch.tensor(view2_b)
        view2_b = view2_b.unsqueeze(0)

        view3_a = self.pathway_drug_a[idx]
        view3_a = torch.tensor(view3_a)
        view3_a = view3_a.unsqueeze(0)

        view3_b = self.pathway_drug_b[idx]
        view3_b = torch.tensor(view3_b)
        view3_b = view3_b.unsqueeze(0)

        label = self.labels[idx]
        label = torch.tensor(label)
        return view1_a, view1_b, view2_a, view2_b, view3_a,  view3_b, label

class MultiViewCNN(nn.Module):
    def __init__(self, T, num_classes):
        super().__init__()
        self.T = T

        self.view1 = SingleViewCNN()
        self.view2 = SingleViewCNN()
        self.view3 = SingleViewCNN()
        #self.view4 = SingleViewCNN()


        self.fc = nn.Sequential(
            nn.Linear(512, 16 * 4 * 4, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Linear(16 * 4 * 4, num_classes, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )
        self.attention = AttentionFusion(16)

    def forward(self, view1_a, view1_b, view2_a, view2_b, view3_a, view3_b):
        view1_a_dataset = [view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a]
        view1_b_dataset = [view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b]
        view2_a_dataset = [view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a]
        view2_b_dataset = [view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b]
        view3_a_dataset = [view3_a, view3_a, view3_a, view3_a, view3_a, view3_a, view3_a,
                           view3_a, view3_a, view3_a]
        view3_b_dataset = [view3_b, view3_b, view3_b, view3_b, view3_b, view3_b, view3_b, view3_b,
                         view3_b, view3_b]


        view1_a_data = view1_a_dataset[0]
        view1_b_data = view1_b_dataset[0]
        view2_a_data = view2_a_dataset[0]
        view2_b_data = view2_b_dataset[0]
        view3_a_data = view3_a_dataset[0]
        view3_b_data = view3_b_dataset[0]

        feat1 = self.view1(view1_a_data, view1_b_data)
        feat2 = self.view2(view2_a_data, view2_b_data)
        feat3 = self.view3(view3_a_data, view3_b_data)
        #feat4 = self.view4(view4_data)
        feat1_np = feat1.cpu().numpy()
        feat2_np = feat2.cpu().numpy()
        feat3_np = feat3.cpu().numpy()
        fused_output, weight_1, weight_2, weight_3 = self.attention(feat1, feat2, feat3)
        fused_output_np = fused_output.cpu().numpy()
        np.save('weight/fused_output_np.npy', fused_output_np)
        #merged_feat = torch.cat((feat1, feat2, feat3), dim=1)
        out_spikes_counter = self.fc(fused_output)

        return out_spikes_counter / self.T, weight_1, weight_2, weight_3

class SingleViewCNN(nn.Module):
    def __init__(self):
        super().__init__()

        self.conv = nn.Sequential(
            # neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None,tau=2.0,v_threshold=1.0),
            neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Conv1d(1, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Conv1d(16, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Flatten()
        )

    def reset_neurons(self):
        for module in self.modules():
            if isinstance(module, (neuron.LIFNode, neuron.IFNode)):
                module.mp_reset()

    def forward(self, drug_a, drug_b):
        rand = torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.float()

        drug_b = drug_b.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_b = drug_b.float()

        # drug_a_np = drug_a.cpu().numpy().reshape(756, 2049)
        # drug_b_np = drug_b.cpu().numpy().reshape(756, 2049)

        # self.reset_neurons()
        fea_a = self.conv(drug_a)
        self.reset_neurons()
        fea_b = self.conv(drug_b)

        fea_a_np = fea_a.cpu().numpy()
        fea_b_np = fea_b.cpu().numpy()
        np.save('weight/fea_a_np.npy', fea_b_np)
        merged_feat = torch.cat((fea_a, fea_b), dim=1)
        return merged_feat


class AttentionFusion(nn.Module):
    def __init__(self, feature_dim):
        super(AttentionFusion, self).__init__()
        self.fc = nn.Linear(3232, 3)  # 3 views, so 3 attention weights
        self.fc1 = nn.Sequential(
            nn.Linear(1024, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(1120, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

        self.fc3 = nn.Sequential(
            nn.Linear(1088, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

    def forward(self, out1, out2, out3):
        # Concatenate features from the three views
        combined = torch.cat((out1, out2, out3), dim=1)  # (batch_size, 3 * feature_dim)

        # Calculate attention weights
        attention_weights = F.softmax(self.fc(combined), dim=1)  # (batch_size, 3)
        # out1_np = out1.cpu().numpy()
        out1 = self.fc1(out1)
        out2 = self.fc2(out2)
        out3 = self.fc3(out3)

        # Apply attention to each view
        weighted_out1 = attention_weights[:, 0].unsqueeze(1) * out1
        weighted_out2 = attention_weights[:, 1].unsqueeze(1) * out2
        weighted_out3 = attention_weights[:, 2].unsqueeze(1) * out3

        weight_1 = attention_weights[:, 0].unsqueeze(1)
        weight_2 = attention_weights[:, 1].unsqueeze(1)
        weight_3 = attention_weights[:, 2].unsqueeze(1)

        # Combine the weighted outputs
        fused_output = weighted_out1 + weighted_out2 + weighted_out3
        fused_output_np = fused_output.cpu().numpy()

        out1_np = out1.cpu().numpy()
        out2_np = out2.cpu().numpy()
        out3_np = out3.cpu().numpy()

        np.save('weight/out1_np.npy', out1_np)
        return fused_output, weight_1, weight_2, weight_3

def calculate_metrics(y_true, y_pred, y_val_bin, num_classes):
    y_pred_class = np.argmax(y_pred, axis=1)

    metrics = {}
    metrics['RMSE'] = np.sqrt(mean_squared_error(y_true, y_pred_class))
    metrics['PCC'], _ = pearsonr(y_true.flatten(), y_pred_class.flatten())
    metrics['ACC'] = accuracy_score(y_true, y_pred_class)
    metrics['Precision'] = precision_score(y_true, y_pred_class, average='macro')
    metrics['F1'] = f1_score(y_true, y_pred_class, average='macro')
    metrics['Recall'] = recall_score(y_true, y_pred_class, average='macro')
    y_pred_class = np.argmax(y_pred, axis=1)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(y_pred.shape[1]):
        fpr[i], tpr[i], _ = roc_curve(y_val_bin[:, i], y_pred[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    values = [v for v in roc_auc.values() if not np.isnan(v)]
    mean_value = np.mean(values)
    Auc = mean_value
    metrics['AUC'] = Auc
    metrics['Kappa'] = cohen_kappa_score(y_true, y_pred_class)
    metrics['PREC'] = precision_score(y_true, y_pred_class, average='micro')  # 可以根据需求自定义

    return metrics
def main():
    current_directory = os.getcwd()
    folder_path = os.path.join(current_directory, 'data', '8anti_mat', 'Redo')
    mat_files = [f for f in os.listdir(folder_path) if f.endswith('.mat')]

    for mat_file in mat_files:

        current_file_name = mat_file[-11:-4]

        file_path = os.path.join(folder_path, mat_file)

        mat_data = scipy.io.loadmat(file_path)
        morgan = mat_data['morgan']
        enzyme = mat_data['enzyme']
        target = mat_data['target']
        pathway = mat_data['pathway']
        gnd = np.squeeze(mat_data['gnd'])

        morgan_drug_a = morgan[:1926, :2049]
        morgan_drug_b = morgan[:1926, 2049:]

        target_drug_a = target[:1926, :2261]
        target_drug_b = target[:1926, 2261:]

        pathway_drug_a = pathway[:1926, :2186]
        pathway_drug_b = pathway[:1926, 2186:]

        max_gnd = max(np.unique(gnd))
        gnd_unique = np.unique(gnd)
        num_classes = len(gnd_unique)
        replace_dict = {old_value: new_value for new_value, old_value in enumerate(gnd_unique)}
        replace_func = np.vectorize(replace_dict.get)
        new_gnd = replace_func(gnd)

        dataset = DrugInteractionDataset(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a,
                                         pathway_drug_b, new_gnd)

        y_bin = label_binarize(new_gnd, classes=list(range(len(gnd_unique))))

        kf = KFold(n_splits=5, shuffle=True, random_state=42)
        fold_results = []

        for fold, (train_idx, val_idx) in enumerate(kf.split(dataset)):

            train_dataset = Subset(dataset, train_idx)
            train_dataset = dataset
            test_dataset = Subset(dataset, val_idx)
            train_loader = DataLoader(train_dataset, batch_size=1296, shuffle=False)
            test_loader = DataLoader(test_dataset, batch_size=len(val_idx), shuffle=False)
            y_val_bin = y_bin[val_idx]
            model = MultiViewCNN(1, num_classes)

            pth_path = os.path.join(current_directory, 'logs', 'T2_DB08828.pth')
            model.load_state_dict(torch.load(pth_path))


            model.eval()


            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            model.to(device)

            with torch.no_grad():
                for morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, label in train_loader:
                    label = label.to(device)
                    label = label.long()
                    label_onehot = F.one_hot(label, len(gnd_unique)).float()
                    outputs, weight_1, weight_2, weight_3 = model(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b)
                    _, predicted = torch.max(outputs, 1)
            predicted = predicted.cpu().numpy()
            label = label.cpu().numpy()
            label_onehot = label_onehot.cpu()
            label_onehot = label_onehot.numpy()
            outputs_np = outputs.cpu().numpy()
            weight_1 = weight_1.cpu().numpy()
            weight_2 = weight_2.cpu().numpy()
            weight_3 = weight_3.cpu().numpy()


            np.save('weight/weight_1.npy', weight_1)
            np.save('weight/weight_2.npy', weight_2)
            np.save('weight/weight_3.npy', weight_3)


            metrics = calculate_metrics(label, outputs_np, y_val_bin, num_classes=len(gnd_unique))
            fold_results.append(metrics)

        final_results = {}
        for metric in fold_results[0].keys():
            values = [fold[metric] for fold in fold_results]
            final_results[f'{metric}_mean'] = np.mean(values)
            final_results[f'{metric}_std'] = np.std(values)


        current_directory = os.getcwd()
        output_dir = os.path.join(current_directory, 'data', 'table', 'multiview-kf')
        filename = current_file_name
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        output_path = os.path.join(output_dir, filename + '.csv')
        df = pd.DataFrame(final_results, index=[0])
        df.to_csv(output_path, index=False)
        result = current_file_name + "   Acc: " + str(final_results['ACC_mean'])
        print(result)



if __name__ == '__main__':
    main()