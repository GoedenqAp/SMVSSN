import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from spikingjelly.clock_driven import neuron, functional, surrogate, layer,encoding
from torch.utils.tensorboard import SummaryWriter
import os
import time
import argparse
import numpy as np
from torch.cuda import amp
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset, random_split
import csv
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import scipy
import pandas as pd




class DrugInteractionDataset(Dataset):
    def __init__(self, morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, enzyme_drug_a, enzyme_drug_b, labels):
        self.morgan_drug_a = morgan_drug_a
        self.morgan_drug_b = morgan_drug_b

        self.target_drug_a = target_drug_a
        self.target_drug_b = target_drug_b

        self.pathway_drug_a = pathway_drug_a
        self.pathway_drug_b = pathway_drug_b

        self.enzyme_drug_a = enzyme_drug_a
        self.enzyme_drug_b = enzyme_drug_b

        self.labels = labels  # 标签

    def __len__(self):
        return len(self.labels)  # 数据集长度

    def __getitem__(self, idx):
        # 返回第 idx 个 drug_a, drug_b 和对应的 label
        view1_a = self.morgan_drug_a[idx]
        view1_a = torch.tensor(view1_a)
        view1_a = view1_a.unsqueeze(0)

        view1_b = self.morgan_drug_b[idx]
        view1_b = torch.tensor(view1_b)
        view1_b = view1_b.unsqueeze(0)

        view2_a = self.target_drug_a[idx]
        view2_a = torch.tensor(view2_a)
        view2_a = view2_a.unsqueeze(0)

        view2_b = self.target_drug_b[idx]
        view2_b = torch.tensor(view2_b)
        view2_b = view2_b.unsqueeze(0)

        view3_a = self.pathway_drug_a[idx]
        view3_a = torch.tensor(view3_a)
        view3_a = view3_a.unsqueeze(0)

        view3_b = self.pathway_drug_b[idx]
        view3_b = torch.tensor(view3_b)
        view3_b = view3_b.unsqueeze(0)

        view4_a = self.enzyme_drug_a[idx]
        view4_a = torch.tensor(view4_a)
        view4_a = view4_a.unsqueeze(0)

        view4_b = self.enzyme_drug_b[idx]
        view4_b = torch.tensor(view4_b)
        view4_b = view4_b.unsqueeze(0)

        label = self.labels[idx]
        label = torch.tensor(label)
        return view1_a, view1_b, view2_a, view2_b, view3_a,  view3_b, view4_a,  view4_b, label




class MultiViewCNN(nn.Module):
    def __init__(self, T, num):
        super().__init__()
        self.T = T

        self.view1 = SingleViewCNN()
        self.view2 = SingleViewCNN()
        self.view3 = SingleViewCNN()
        self.view4 = SingleViewCNN()


        self.fc = nn.Sequential(
            nn.Linear(512, 16 * 4 * 4, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Linear(16 * 4 * 4, num, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )
        self.attention = AttentionFusion(16)

    def forward(self, view1_a, view1_b, view2_a, view2_b, view3_a, view3_b, view4_a, view4_b):
        view1_a_dataset = [view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a]
        view1_b_dataset = [view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b]
        view2_a_dataset = [view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a]
        view2_b_dataset = [view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b]
        view3_a_dataset = [view3_a, view3_a, view3_a, view3_a, view3_a, view3_a, view3_a,
                           view3_a, view3_a, view3_a]
        view3_b_dataset = [view3_b, view3_b, view3_b, view3_b, view3_b, view3_b, view3_b, view3_b,
                         view3_b, view3_b]
        view4_a_dataset = [view4_a, view4_a, view4_a, view4_a, view4_a, view4_a, view4_a,
                           view4_a, view4_a, view4_a]
        view4_b_dataset = [view4_b, view4_b, view4_b, view4_b, view4_b, view4_b, view4_b, view4_b,
                           view4_b, view4_b]



        view1_a_data = view1_a_dataset[0]
        view1_b_data = view1_b_dataset[0]
        view2_a_data = view2_a_dataset[0]
        view2_b_data = view2_b_dataset[0]
        view3_a_data = view3_a_dataset[0]
        view3_b_data = view3_b_dataset[0]
        view4_a_data = view4_a_dataset[0]
        view4_b_data = view4_b_dataset[0]

        feat1 = self.view1(view1_a_data, view1_b_data)
        feat2 = self.view2(view2_a_data, view2_b_data)
        feat3 = self.view3(view3_a_data, view3_b_data)
        feat4 = self.view4(view4_a_data, view4_b_data)

        fused_output, weight_1, weight_2, weight_3, weight_4 = self.attention(feat1, feat2, feat3, feat4)
        #merged_feat = torch.cat((feat1, feat2, feat3), dim=1)
        out_spikes_counter = self.fc(fused_output)

        for t in range(1, self.T):
            view1_a_data = view1_a_dataset[t]
            view1_b_data = view1_b_dataset[t]
            view2_a_data = view2_a_dataset[t]
            view2_b_data = view2_b_dataset[t]
            view3_a_data = view3_a_dataset[t]
            view3_b_data = view3_b_dataset[t]
            view4_a_data = view4_a_dataset[t]
            view4_b_data = view4_b_dataset[t]

            feat1 = self.view1(view1_a_data, view1_b_data)
            feat2 = self.view2(view2_a_data, view2_b_data)
            feat3 = self.view3(view3_a_data, view3_b_data)
            feat4 = self.view4(view4_a_data, view4_b_data)

            fused_output, weight_1, weight_2, weight_3, weight_4 = self.attention(feat1, feat2, feat3, feat4)
            out_spikes_counter += self.fc(fused_output)
        return out_spikes_counter / self.T, weight_1, weight_2, weight_3, weight_4

class SingleViewCNN(nn.Module):
    def __init__(self):
        super().__init__()

        self.conv = nn.Sequential(
            # neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None,tau=2.0,v_threshold=1.0),
            neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Conv1d(1, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Conv1d(16, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Flatten()
        )


    def forward(self, drug_a, drug_b):
        rand = torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.float()

        drug_b = drug_b.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_b = drug_b.float()


        fea_a = self.conv(drug_a)
        fea_b = self.conv(drug_b)
        merged_feat = torch.cat((fea_a, fea_b), dim=1)
        return merged_feat


class AttentionFusion(nn.Module):
    def __init__(self, feature_dim):
        super(AttentionFusion, self).__init__()
        self.fc = nn.Linear(3392, 4)  # 3 views, so 3 attention weights
        self.fc1 = nn.Sequential(
            nn.Linear(1024, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(1120, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

        self.fc3 = nn.Sequential(
            nn.Linear(1088, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )
        self.fc4 = nn.Sequential(
            nn.Linear(160, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

    def forward(self, out1, out2, out3, out4):
        # Concatenate features from the three views
        combined = torch.cat((out1, out2, out3, out4), dim=1)  # (batch_size, 3 * feature_dim)

        # Calculate attention weights
        attention_weights = F.softmax(self.fc(combined), dim=1)  # (batch_size, 3)

        out1 = self.fc1(out1)
        out2 = self.fc2(out2)
        out3 = self.fc3(out3)
        out4 = self.fc4(out4)

        # Apply attention to each view
        weighted_out1 = attention_weights[:, 0].unsqueeze(1) * out1
        weighted_out2 = attention_weights[:, 1].unsqueeze(1) * out2
        weighted_out3 = attention_weights[:, 2].unsqueeze(1) * out3
        weighted_out4 = attention_weights[:, 3].unsqueeze(1) * out4

        weight_1 = attention_weights[:, 0].unsqueeze(1)
        weight_2 = attention_weights[:, 1].unsqueeze(1)
        weight_3 = attention_weights[:, 2].unsqueeze(1)
        weight_4 = attention_weights[:, 3].unsqueeze(1)

        # Combine the weighted outputs
        fused_output = weighted_out1 + weighted_out2 + weighted_out3 + weighted_out4

        return fused_output, weight_1, weight_2, weight_3, weight_4


def main():

    current_directory = os.getcwd()
    folder_path = os.path.join(current_directory, 'data', '8anti_mat')
    mat_files = [f for f in os.listdir(folder_path) if f.endswith('.mat')]

    for mat_file in mat_files:
        #mat_path = os.path.join(current_directory, 'data', '8anti_mat', 'new_all_DB09053.mat')
        #mat_data = scipy.io.loadmat(mat_file)
        current_file_name = mat_file[-11:-4]


        file_path = os.path.join(folder_path, mat_file)

        mat_data = scipy.io.loadmat(file_path)
        morgan = mat_data['morgan']
        enzyme = mat_data['enzyme']
        target = mat_data['target']
        pathway = mat_data['pathway']
        gnd = np.squeeze(mat_data['gnd'])

        morgan_drug_a = morgan[:1926, :2049]
        morgan_drug_b = morgan[:1926, 2049:]

        target_drug_a = target[:1926, :2261]
        target_drug_b = target[:1926, 2261:]

        pathway_drug_a = pathway[:1926, :2186]
        pathway_drug_b = pathway[:1926, 2186:]

        enzyme_drug_a = enzyme[:1926, :330]
        enzyme_drug_b = enzyme[:1926, 330:]

        gnd_unique = np.unique(gnd)
        num_class = len(gnd_unique)
        replace_dict = {old_value: new_value for new_value, old_value in enumerate(gnd_unique)}
        replace_func = np.vectorize(replace_dict.get)
        new_gnd = replace_func(gnd)

        dataset = DrugInteractionDataset(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a,
                                         pathway_drug_b, enzyme_drug_a, enzyme_drug_b, new_gnd)
        train_size = int(0.8 * len(dataset))
        test_size = len(dataset) - train_size
        train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
        train_loader = DataLoader(dataset, batch_size=train_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=test_size, shuffle=False)

        pth_path = os.path.join(current_directory, 'logs', '4-view', current_file_name+'.pth')

        model = MultiViewCNN(10, len(gnd_unique))


        model.load_state_dict(torch.load(pth_path))


        model.eval()


        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        model.to(device)

        with torch.no_grad():
            for morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, enzyme_drug_a, enzyme_drug_b, label in test_loader:
                label = label.to(device)
                label = label.long()
                label_onehot = F.one_hot(label, len(gnd_unique)).float()
                out_fr, weight_1, weight_2, weight_3, weight_4 = model(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, enzyme_drug_a, enzyme_drug_b)




        weight1_mean = weight_1.cpu().numpy().mean(axis=0)
        weight2_mean = weight_2.cpu().numpy().mean(axis=0)
        weight3_mean = weight_3.cpu().numpy().mean(axis=0)
        weight4_mean = weight_4.cpu().numpy().mean(axis=0)

        plt.figure(figsize=(10, 6))
        plt.plot(weight_1.cpu().numpy()[:20], color='blue', linestyle='-', marker='o', label='SMILES')
        plt.plot(weight_2.cpu().numpy()[:20], color='orange', linestyle='-', marker='s', label='Target')
        plt.plot(weight_3.cpu().numpy()[:20], color='green', linestyle='-', marker='^', label='Pathway')
        plt.plot(weight_4.cpu().numpy()[:20], color='red', linestyle='-', marker='x', alpha=0.7, label='Enzyme')


        plt.xlim(0, 19)
        plt.xticks(np.arange(20))
        plt.xlabel('Sample')
        plt.ylabel('Proportion of weight')
        #plt.legend()
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, 1.05), ncol=4, fontsize='large', frameon=False)
        plt.grid(False)
        project_root = os.getcwd()
        pic_path = os.path.join(project_root, '画图', '折线', current_file_name + '_plot.png')
        plt.savefig(pic_path, dpi=300, bbox_inches='tight')
        #plt.show()
        #weight1_mean = weight_1.cpu().numpy().mean(axis=0)
if __name__ == '__main__':
    main()