import numpy as np
# print(1)
import matplotlib.pyplot as plt
import os
from sklearn.datasets import fetch_lfw_people
from skimage.transform import resize
import torch
import scipy

# 读取 .mat 文件
current_directory = os.getcwd()
mat_path = os.path.join(current_directory, 'data', '8anti_mat', 'new_all_DB08828.mat')
mat_data = scipy.io.loadmat(mat_path)
morgan = mat_data['morgan']
enzyme = mat_data['enzyme']
target = mat_data['target']
pathway = mat_data['pathway']
gnd = np.squeeze(mat_data['gnd'])

morgan_drug_a_np = morgan[:1926, :2048]
morgan_drug_b_np = morgan[:1926, 2049:4097]

data = c = np.hstack((morgan_drug_a_np, morgan_drug_b_np))
data_1 = data[0]
# 获取当前工作目录
# project_root = os.getcwd()
# # 将当前工作目录与其他路径部分连接
# data_dir = os.path.join(project_root, 'run', 'Traffic_Reco_soft', '32_GTSRB_attention', '2.npy')
# data = np.load(data_dir).reshape((1,1024)).astype("int")
# data = np.load(r'F:\TSRD\Traffic_Reco_soft\Traffic_Reco\Serial_Send\GTSRB_attention\0.npy').reshape((1,784)).astype("int")
# data = np.load(r'F:\TSRD\Traffic_Reco_soft\Traffic_Reco\Serial_Send\GTSRB\shuffle_dataset\0.npy')
# data = np.load(r'F:\TSRD\Traffic_Reco_soft\Traffic_Reco\Serial_Send\GTSRB_attention\0.npy')
# print(data.shape)
# data = np.loadtxt('E:\Python_Project\Acce_Test\MNIST_Fashion\mnist_fashion_test/{}.txt'.format(index)).reshape((1,784)).astype("int")




print(data_1)
with open('drug_1.coe','w') as f:
    # f.writelines("initial begin\n")
    f.writelines("MEMORY_INITIALIZATION_RADIX=16;\n")
    f.writelines("MEMORY_INITIALIZATION_VECTOR=\n")
    for i in range(len(data_1)):
        # a = hex(data[0][i]).replace('0x','')
        # print(a)
        # f.writelines("image1[{0}] = {1};\n".format(i,data[0][i]))
        x = data_1[i].astype(int)
        f.writelines(np.array2string(x, separator=',') + '\n')

    # f.writelines('end')
#plt.imshow(np.load(r'F:\TSRD\Traffic_Reco_soft\Traffic_Reco\Serial_Send\32_GTSRB_attention\0.npy'),cmap='gray')
# plt.imshow(np.load(r'F:\TSRD\Traffic_Reco_soft\Traffic_Reco\Serial_Send\GTSRB_attention\6.npy'),cmap='gray')
#plt.show()