import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from spikingjelly.clock_driven import neuron, functional, surrogate, layer,encoding
from torch.utils.tensorboard import SummaryWriter
import os
import time
import argparse
import numpy as np
from torch.cuda import amp
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset, random_split
import csv
import os
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import scipy
import pandas as pd




class DrugInteractionDataset(Dataset):
    def __init__(self, morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, labels):
        self.morgan_drug_a = morgan_drug_a
        self.morgan_drug_b = morgan_drug_b

        self.target_drug_a = target_drug_a
        self.target_drug_b = target_drug_b

        self.pathway_drug_a = pathway_drug_a
        self.pathway_drug_b = pathway_drug_b

        self.labels = labels  # 标签

    def __len__(self):
        return len(self.labels)  # 数据集长度

    def __getitem__(self, idx):
        # 返回第 idx 个 drug_a, drug_b 和对应的 label
        view1_a = self.morgan_drug_a[idx]
        view1_a = torch.tensor(view1_a)
        view1_a = view1_a.unsqueeze(0)

        view1_b = self.morgan_drug_b[idx]
        view1_b = torch.tensor(view1_b)
        view1_b = view1_b.unsqueeze(0)

        view2_a = self.target_drug_a[idx]
        view2_a = torch.tensor(view2_a)
        view2_a = view2_a.unsqueeze(0)

        view2_b = self.target_drug_b[idx]
        view2_b = torch.tensor(view2_b)
        view2_b = view2_b.unsqueeze(0)

        view3_a = self.pathway_drug_a[idx]
        view3_a = torch.tensor(view3_a)
        view3_a = view3_a.unsqueeze(0)

        view3_b = self.pathway_drug_b[idx]
        view3_b = torch.tensor(view3_b)
        view3_b = view3_b.unsqueeze(0)

        label = self.labels[idx]
        label = torch.tensor(label)
        return view1_a, view1_b, view2_a, view2_b, view3_a,  view3_b, label




class MultiViewCNN(nn.Module):
    def __init__(self, T, num):
        super().__init__()
        self.T = T
        # 四个视图分别对应四个 CNN 子网络
        self.view1 = SingleViewCNN()
        self.view2 = SingleViewCNN()
        self.view3 = SingleViewCNN()
        #self.view4 = SingleViewCNN()

        # 合并特征并进行分类
        self.fc = nn.Sequential(
            nn.Linear(512, 16 * 4 * 4, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Linear(16 * 4 * 4, num, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )
        self.attention = AttentionFusion(16)

    def forward(self, view1_a, view1_b, view2_a, view2_b, view3_a, view3_b):
        view1_a_dataset = [view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a]
        view1_b_dataset = [view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b]
        view2_a_dataset = [view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a]
        view2_b_dataset = [view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b]
        view3_a_dataset = [view3_a, view3_a, view3_a, view3_a, view3_a, view3_a, view3_a,
                           view3_a, view3_a, view3_a]
        view3_b_dataset = [view3_b, view3_b, view3_b, view3_b, view3_b, view3_b, view3_b, view3_b,
                         view3_b, view3_b]


        view1_a_data = view1_a_dataset[0]
        view1_b_data = view1_b_dataset[0]
        view2_a_data = view2_a_dataset[0]
        view2_b_data = view2_b_dataset[0]
        view3_a_data = view3_a_dataset[0]
        view3_b_data = view3_b_dataset[0]
        # 每个视图分别通过其对应的 CNN 网络
        feat1 = self.view1(view1_a_data, view1_b_data)
        feat2 = self.view2(view2_a_data, view2_b_data)
        feat3 = self.view3(view3_a_data, view3_b_data)
        #feat4 = self.view4(view4_data)

        fused_output, weight_1, weight_2, weight_3 = self.attention(feat1, feat2, feat3)
        #merged_feat = torch.cat((feat1, feat2, feat3), dim=1)
        out_spikes_counter = self.fc(fused_output)

        return out_spikes_counter

class SingleViewCNN(nn.Module):
    def __init__(self):
        super().__init__()
        # 定义CNN结构
        self.conv = nn.Sequential(
            # neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None,tau=2.0,v_threshold=1.0),
            neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Conv1d(1, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Conv1d(16, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Flatten()
        )

    def reset_neurons(self):
        for module in self.modules():
            if isinstance(module, (neuron.LIFNode, neuron.IFNode)):
                module.mp_reset()  # 重置膜电位

    def forward(self, drug_a, drug_b):
        rand = torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.float()

        drug_b = drug_b.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_b = drug_b.float()

        # 通过共享CNN提取特征
        fea_a = self.conv(drug_a)
        self.reset_neurons()
        fea_b = self.conv(drug_b)
        merged_feat = torch.cat((fea_a, fea_b), dim=1)
        return merged_feat


class AttentionFusion(nn.Module):
    def __init__(self, feature_dim):
        super(AttentionFusion, self).__init__()
        self.fc = nn.Linear(3232, 3)  # 3 views, so 3 attention weights
        self.fc1 = nn.Sequential(
            nn.Linear(1024, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(1120, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

        self.fc3 = nn.Sequential(
            nn.Linear(1088, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

    def forward(self, out1, out2, out3):
        # Concatenate features from the three views
        combined = torch.cat((out1, out2, out3), dim=1)  # (batch_size, 3 * feature_dim)

        # Calculate attention weights
        attention_weights = F.softmax(self.fc(combined), dim=1)  # (batch_size, 3)

        out1 = self.fc1(out1)
        out2 = self.fc2(out2)
        out3 = self.fc3(out3)

        # Apply attention to each view
        weighted_out1 = attention_weights[:, 0].unsqueeze(1) * out1
        weighted_out2 = attention_weights[:, 1].unsqueeze(1) * out2
        weighted_out3 = attention_weights[:, 2].unsqueeze(1) * out3

        weight_1 = attention_weights[:, 0].unsqueeze(1)
        weight_2 = attention_weights[:, 1].unsqueeze(1)
        weight_3 = attention_weights[:, 2].unsqueeze(1)

        # Combine the weighted outputs
        fused_output = weighted_out1 + weighted_out2 + weighted_out3

        return fused_output, weight_1, weight_2, weight_3


def main():
    # 读取 .mat 文件
    current_directory = os.getcwd()
    mat_path = os.path.join(current_directory, 'data', '8anti_mat', 'new_all_DB08828.mat')
    mat_data = scipy.io.loadmat(mat_path)
    morgan = mat_data['morgan']
    enzyme = mat_data['enzyme']
    target = mat_data['target']
    pathway = mat_data['pathway']
    gnd = np.squeeze(mat_data['gnd'])

    morgan_drug_a = morgan[:1926, :2049]
    morgan_drug_b = morgan[:1926, 2049:]

    target_drug_a = target[:1926, :2261]
    target_drug_b = target[:1926, 2261:]

    pathway_drug_a = pathway[:1926, :2186]
    pathway_drug_b = pathway[:1926, 2186:]

    enzyme_drug_a = enzyme[:1926, :330]
    enzyme_drug_b = enzyme[:1926, 330:]

    gnd_unique = np.unique(gnd)
    num_class = len(gnd_unique)
    replace_dict = {old_value: new_value for new_value, old_value in enumerate(gnd_unique)}
    replace_func = np.vectorize(replace_dict.get)
    new_gnd = replace_func(gnd)
    # 制作数据集
    dataset = DrugInteractionDataset(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a,
                                     pathway_drug_b, new_gnd)
    train_size = int(0.7 * len(dataset))
    test_size = len(dataset) - train_size
    train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
    train_loader = DataLoader(dataset, batch_size=64, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

    # 获取当前工作目录
    project_root = os.getcwd()
    print(torch.cuda.is_available())
    # 将当前工作目录与其他路径部分连接
    data_dir = os.path.join(project_root)

    parser = argparse.ArgumentParser(description='Classify Fashion-MNIST')
    parser.add_argument('-T', default=10, type=int, help='simulating time-steps')
    parser.add_argument('-device', default='cuda:0', help='device')
    parser.add_argument('-b', default=32, type=int, help='batch size')
    parser.add_argument('-epochs', default=1200, type=int, metavar='N',
                        help='number of total epochs to run')
    parser.add_argument('-j', default=1, type=int, metavar='N',
                        help='number of data loading workers (default: 4)')
    parser.add_argument('-data_dir', type=str,default=data_dir, help='root dir of Fashion-MNIST dataset')
    parser.add_argument('-out_dir', type=str, default='./logs', help='root dir for saving logs and checkpoint')
    parser.add_argument('-resume', type=str, help='resume from the checkpoint path')
    parser.add_argument('-amp', action='store_true', help='automatic mixed precision training')
    parser.add_argument('-opt', default='Adam',type=str, help='use which optimizer. SDG or Adam')
    parser.add_argument('-lr', default=0.001, type=float, help='learning rate')
    parser.add_argument('-momentum', default=0.9, type=float, help='momentum for SGD')
    parser.add_argument('-lr_scheduler', default='CosALR', type=str, help='use which schedule. StepLR or CosALR')
    parser.add_argument('-step_size', default=32, type=float, help='step_size for StepLR')
    parser.add_argument('-gamma', default=0.1, type=float, help='gamma for StepLR')
    parser.add_argument('-T_max', default=64, type=int, help='T_max for CosineAnnealingLR')
    # python spikingjelly_scnn_lif.py -amp -cupy
    args = parser.parse_args()
    print(args)
    net = MultiViewCNN(10, len(gnd_unique))
    print(net)
    net.to(args.device)

    optimizer = None
    if args.opt == 'SDG':
        optimizer = torch.optim.SGD(net.parameters(), lr=args.lr, momentum=args.momentum)
    elif args.opt == 'Adam':
        optimizer = torch.optim.Adam(net.parameters(), lr=args.lr)
    else:
        raise NotImplementedError(args.opt)

    lr_scheduler = None
    if args.lr_scheduler == 'StepLR':
        lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=args.step_size, gamma=args.gamma)
    elif args.lr_scheduler == 'CosALR':
        lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.T_max)
    else:
        raise NotImplementedError(args.lr_scheduler)



    scaler = None
    if args.amp:
        scaler = amp.GradScaler()

    start_epoch = 0
    max_test_acc = 0

    if args.resume:
        checkpoint = torch.load(args.resume, map_location='cpu')
        net.load_state_dict(checkpoint['net'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
        start_epoch = checkpoint['epoch'] + 1
        max_test_acc = checkpoint['max_test_acc']

    out_dir = args.out_dir

    if not os.path.exists(out_dir):
        os.mkdir(out_dir)
        print(f'Mkdir {out_dir}.')

    with open(os.path.join(out_dir, 'args.txt'), 'w', encoding='utf-8') as args_txt:
        args_txt.write(str(args))

    writer = SummaryWriter(os.path.join(out_dir, 'TR_logs'), purge_step=start_epoch)

    for epoch in range(start_epoch, args.epochs):
        start_time = time.time()
        net.train()
        train_loss = 0
        train_acc = 0
        train_samples = 0
        for morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, label in train_loader:
            optimizer.zero_grad()
            label = label.to(args.device)
            label = label.long()
            label_onehot = F.one_hot(label, len(gnd_unique)).float()
            if args.amp:
                with amp.autocast():
                    out_fr = net(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b)
                    loss = F.mse_loss(out_fr, label_onehot)
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
            else:
                out_fr = net(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b)
                loss = F.mse_loss(out_fr, label_onehot)
                loss.backward()
                optimizer.step()

            train_samples += label.numel()
            train_loss += loss.item() * label.numel()
            train_acc += (out_fr.argmax(1) == label).float().sum().item()

            functional.reset_net(net)
        train_loss /= train_samples
        train_acc /= train_samples

        writer.add_scalar('train_loss', train_loss, epoch)
        writer.add_scalar('train_acc', train_acc, epoch)
        lr_scheduler.step()

        net.eval()
        test_loss = 0
        test_acc = 0
        test_samples = 0
        with torch.no_grad():
            for morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, label in test_loader:

                label = label.to(args.device)
                label = label.long()
                label_onehot = F.one_hot(label, len(gnd_unique)).float()
                out_fr = net(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b)
                loss = F.mse_loss(out_fr, label_onehot)

                test_samples += label.numel()
                test_loss += loss.item() * label.numel()
                test_acc += (out_fr.argmax(1) == label).float().sum().item()
                functional.reset_net(net)

        test_loss /= test_samples
        test_acc /= test_samples
        writer.add_scalar('test_loss', test_loss, epoch)
        writer.add_scalar('test_acc', test_acc, epoch)

        save_max = False
        if test_acc > max_test_acc:
            max_test_acc = test_acc
            save_max = True

        checkpoint = {
            'net': net.state_dict(),
            'optimizer': optimizer.state_dict(),
            'lr_scheduler': lr_scheduler.state_dict(),
            'epoch': epoch,
            'max_test_acc': max_test_acc
        }

        if save_max:
            # 获取当前工作目录
            project_root = os.getcwd()

            # 将当前工作目录与其他路径部分连接
            model_path = os.path.join(project_root, 'logs', 'DB08828.pth')
            torch.save(net.state_dict(), model_path)

        torch.save(checkpoint, os.path.join(out_dir, 'checkpoint_latest.pth'))
        # torch.save(net.state_dict(), 'E:\Python_Project\ANN_2_SNN\Traffic_Reco\direct_train\SNN.pth' )

        print(
            f'epoch={epoch}, train_loss={train_loss}, train_acc={train_acc}, test_loss={test_loss}, test_acc={test_acc}, max_test_acc={max_test_acc}, total_time={time.time() - start_time}')


if __name__ == '__main__':
    main()