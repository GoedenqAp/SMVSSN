import pandas as pd
import glob
import os

current_directory = os.getcwd()
folder_path = os.path.join(current_directory, 'data', 'table', 'multiview-kf')
# 指定包含多个 CSV 文件的文件夹路径
csv_folder = folder_path

# 获取文件夹下所有 CSV 文件路径
csv_files = glob.glob(os.path.join(csv_folder, "*.csv"))

# 定义需要合并的列对
metrics = ["RMSE", "PCC", "ACC", "Precision", "F1", "Recall", "AUC", "Kappa", "PREC"]

# 使用 Unicode 的 ± 符号
plus_minus = '\u00B1'

# 遍历每个 CSV 文件
for file in csv_files:
    # 读取 CSV 文件，假设第一列是需要保留的列
    df = pd.read_csv(file)

    # 新的 DataFrame 用于存放合并后的结果，并保留第一列
    new_df = pd.DataFrame()

    # 保留第一列数据
    new_df[df.columns[0]] = df.iloc[:, 0]

    # 对于每一个需要合并的指标列，进行 mean 和 std 的合并
    for metric in metrics:
        mean_col = f"{metric}_mean"
        std_col = f"{metric}_std"

        # 检查是否存在 mean 和 std 列
        if mean_col in df.columns and std_col in df.columns:
            # 合并 mean 和 std 列，格式为 "mean±std"，保留 4 位小数
            new_df[metric] = df[mean_col].round(4).astype(str) + plus_minus + df[std_col].round(2).astype(str)

    # 打印处理的文件名
    print(f"Processed file: {os.path.basename(file)}")
    print(new_df)

    # 创建输出文件夹，如果不存在则创建
    output_folder = os.path.join(csv_folder, "SNRMPACDC_processed_xlsx")
    os.makedirs(output_folder, exist_ok=True)

    # 保存为 Excel 文件
    output_file = os.path.join(output_folder, "processed_" + os.path.basename(file).replace(".csv", ".xlsx"))
    with pd.ExcelWriter(output_file, engine='xlsxwriter') as writer:
        new_df.to_excel(writer, index=False)

    print(f"Saved to: {output_file}\n")