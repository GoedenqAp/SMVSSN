import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from spikingjelly.clock_driven import neuron, functional, surrogate, layer,encoding
from torch.utils.tensorboard import SummaryWriter
import os
import time
import argparse
import numpy as np
from scipy import interp
from torch.cuda import amp
import torchvision.transforms as transforms
from scipy.stats import pearsonr
from torch.utils.data import DataLoader, Dataset, random_split, Subset
from itertools import cycle
import csv
import os
from sklearn.model_selection import train_test_split
import scipy
from sklearn.model_selection import KFold
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, mean_squared_error, roc_curve, auc
from sklearn.metrics import cohen_kappa_score, matthews_corrcoef, r2_score
from sklearn.preprocessing import label_binarize
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
import warnings
# 抑制所有警告
warnings.filterwarnings("ignore")

class DrugInteractionDataset(Dataset):
    def __init__(self, morgan_drug_a, morgan_drug_b, labels):
        self.morgan_drug_a = morgan_drug_a
        self.morgan_drug_b = morgan_drug_b
        self.labels = labels  # 标签

    def __len__(self):
        return len(self.labels)  # 数据集长度

    def __getitem__(self, idx):
        # 返回第 idx 个 drug_a, drug_b 和对应的 label
        view1_a = self.morgan_drug_a[idx]
        view1_a = torch.tensor(view1_a)
        view1_a = view1_a.unsqueeze(0)

        view1_b = self.morgan_drug_b[idx]
        view1_b = torch.tensor(view1_b)
        view1_b = view1_b.unsqueeze(0)


        label = self.labels[idx]
        label = torch.tensor(label)
        return view1_a, view1_b, label

class MultiViewCNN(nn.Module):
    def __init__(self, T, num_classes):
        super().__init__()
        self.T = T
        # 四个视图分别对应四个 CNN 子网络
        self.view1 = SingleViewCNN()

        # 合并特征并进行分类
        self.fc = nn.Sequential(
            nn.Linear(1024, 16 * 4 * 4, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Linear(16 * 4 * 4, num_classes, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )


    def forward(self, view1_a, view1_b):
        view1_a_dataset = [view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a]
        view1_b_dataset = [view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b]
        view1_a_data = view1_a_dataset[0]
        view1_b_data = view1_b_dataset[0]
        # 每个视图分别通过其对应的 CNN 网络
        feat1 = self.view1(view1_a_data, view1_b_data)

        # np.save('weight/feat1.npy', feat1)
        #merged_feat = torch.cat((feat1, feat2, feat3), dim=1)
        out_spikes_counter = self.fc(feat1)

        return out_spikes_counter / self.T

class SingleViewCNN(nn.Module):
    def __init__(self):
        super().__init__()
        # 定义CNN结构
        self.conv = nn.Sequential(
            # neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None,tau=2.0,v_threshold=1.0),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Conv1d(1, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Conv1d(16, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Flatten()
        )

    def reset_neurons(self):
        for module in self.modules():
            if isinstance(module, (neuron.LIFNode, neuron.IFNode)):
                module.mp_reset()  # 重置膜电位

    def forward(self, drug_a, drug_b):
        rand = torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.float()

        drug_b = drug_b.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_b = drug_b.float()

        # drug_a_np = drug_a.cpu().numpy().reshape(756, 2049)
        # drug_b_np = drug_b.cpu().numpy().reshape(756, 2049)
        # 通过共享CNN提取特征
        # self.reset_neurons()
        fea_a = self.conv(drug_a)
        self.reset_neurons()
        fea_b = self.conv(drug_b)

        fea_a_np = fea_a.cpu().numpy()
        fea_b_np = fea_b.cpu().numpy()
        np.save('weight/fea_a_np.npy', fea_b_np)
        merged_feat = torch.cat((fea_a, fea_b), dim=1)
        return merged_feat



def calculate_metrics(y_true, y_pred, y_val_bin, num_classes):
    y_pred_class = np.argmax(y_pred, axis=1)

    metrics = {}
    metrics['RMSE'] = np.sqrt(mean_squared_error(y_true, y_pred_class))
    metrics['PCC'], _ = pearsonr(y_true.flatten(), y_pred_class.flatten())
    metrics['ACC'] = accuracy_score(y_true, y_pred_class)
    metrics['Precision'] = precision_score(y_true, y_pred_class, average='macro')
    metrics['F1'] = f1_score(y_true, y_pred_class, average='macro')
    metrics['Recall'] = recall_score(y_true, y_pred_class, average='macro')
    y_pred_class = np.argmax(y_pred, axis=1)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(y_pred.shape[1]):
        fpr[i], tpr[i], _ = roc_curve(y_val_bin[:, i], y_pred[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    values = [v for v in roc_auc.values() if not np.isnan(v)]
    mean_value = np.mean(values)
    Auc = mean_value
    metrics['AUC'] = Auc
    metrics['Kappa'] = cohen_kappa_score(y_true, y_pred_class)
    metrics['PREC'] = precision_score(y_true, y_pred_class, average='micro')  # 可以根据需求自定义

    return metrics
def main():
    current_directory = os.getcwd()
    folder_path = os.path.join(current_directory, 'data', '8anti_mat', 'Redo')
    mat_files = [f for f in os.listdir(folder_path) if f.endswith('.mat')]

    for mat_file in mat_files:
        # 保存当前文件名到变量
        current_file_name = mat_file[-11:-4]
        # 构建完整文件路径
        file_path = os.path.join(folder_path, mat_file)
        # 读取 .mat 文件
        mat_data = scipy.io.loadmat(file_path)
        morgan = mat_data['morgan']
        enzyme = mat_data['enzyme']
        target = mat_data['target']
        pathway = mat_data['pathway']
        gnd = np.squeeze(mat_data['gnd'])

        morgan_drug_a = morgan[:1926, :2048]
        morgan_drug_b = morgan[:1926, 2049:4097]

        max_gnd = max(np.unique(gnd))
        gnd_unique = np.unique(gnd)
        num_classes = len(gnd_unique)
        replace_dict = {old_value: new_value for new_value, old_value in enumerate(gnd_unique)}
        replace_func = np.vectorize(replace_dict.get)
        new_gnd = replace_func(gnd)
        # 制作数据集
        dataset = DrugInteractionDataset(morgan_drug_a, morgan_drug_b, new_gnd)

        y_bin = label_binarize(new_gnd, classes=list(range(len(gnd_unique))))
        # 使用KFold划分数据
        kf = KFold(n_splits=5, shuffle=True, random_state=42)
        fold_results = []

        for fold, (train_idx, val_idx) in enumerate(kf.split(dataset)):
        # 实例化模型
            train_dataset = Subset(dataset, train_idx)
            train_dataset = dataset
            test_dataset = Subset(dataset, val_idx)
            train_loader = DataLoader(train_dataset, batch_size=1296, shuffle=False)
            test_loader = DataLoader(test_dataset, batch_size=len(val_idx), shuffle=False)
            y_val_bin = y_bin[val_idx]
            model = MultiViewCNN(1, num_classes)
            # 加载已保存的模型权重
            pth_path = os.path.join(current_directory, 'logs', 'Single_DB08828.pth')
            model.load_state_dict(torch.load(pth_path))

            # 设置模型为评估模式
            model.eval()

            # 将模型移动到GPU（如果有）
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            model.to(device)
            # 在测试集上运行模型
            with torch.no_grad():  # 关闭梯度计算
                for morgan_drug_a, morgan_drug_b, label in train_loader:
                    label = label.to(device)
                    label = label.long()
                    label_onehot = F.one_hot(label, len(gnd_unique)).float()
                    outputs = model(morgan_drug_a, morgan_drug_b)
                    _, predicted = torch.max(outputs, 1)
            predicted = predicted.cpu().numpy()
            label = label.cpu().numpy()
            label_onehot = label_onehot.cpu()
            label_onehot = label_onehot.numpy()
            outputs_np = outputs.cpu().numpy()



            metrics = calculate_metrics(label, outputs_np, y_val_bin, num_classes=len(gnd_unique))
            fold_results.append(metrics)

        final_results = {}
        for metric in fold_results[0].keys():
            values = [fold[metric] for fold in fold_results]
            final_results[f'{metric}_mean'] = np.mean(values)
            final_results[f'{metric}_std'] = np.std(values)




if __name__ == '__main__':
    main()