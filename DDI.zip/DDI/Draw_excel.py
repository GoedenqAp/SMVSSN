import pandas as pd
import matplotlib.pyplot as plt
from pychart import *
# 读取 Excel 文件
file_path = '实验表格.xlsx'  # 替换为你的文件路径
df = pd.read_excel(file_path, sheet_name='权重')


# 设置图形输出
def create_pie_chart(dataset_name, sizes):
    chart = pie.Pie()
    chart.data = sizes
    chart.labels = ['数据1', '数据2', '数据3', '数据4']  # 标签
    chart.color = [0, 1, 2, 3]  # 颜色索引
    chart.title = f'饼状图: {dataset_name}'

    # 输出图形
    chart.draw()

# 假设每一行有四个数据，构成一个饼状图
for index, row in df.iterrows():
    labels = ['morgan', 'target', 'pathway', 'enzyme']  # 标签
    sizes = row[1:5].values  # 每行的数据
    colors = ['gold', 'lightcoral', 'lightskyblue', 'yellowgreen']  # 颜色
    explode = (0.01, 0.01, 0.01, 0.01)  # 使第一块稍微突出

    # 绘制饼状图
    plt.figure()
    plt.pie(sizes, explode=explode, labels=labels, colors=colors,
            autopct='%1.1f%%', shadow=0, startangle=0, labeldistance=0.8)
    plt.axis('equal')  # 使饼图为圆形
    #plt.title(f'饼状图 {index + 1}')
    plt.show()
    explode = (0.1, 0, 0, 0)
