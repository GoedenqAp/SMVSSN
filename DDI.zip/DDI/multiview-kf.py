import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.stats import pearsonr
from sklearn.model_selection import KFold
from sklearn.preprocessing import label_binarize
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, mean_squared_error, roc_curve, auc
from sklearn.metrics import cohen_kappa_score
from spikingjelly.clock_driven import neuron, functional, surrogate, layer,encoding
from torch.utils.tensorboard import SummaryWriter
import argparse
import numpy as np
from torch.cuda import amp
from torch.utils.data import DataLoader, Dataset, Subset
import os
import scipy
import pandas as pd
import warnings
import time
# 抑制所有警告
warnings.filterwarnings("ignore")

class MultiViewCNN(nn.Module):
    def __init__(self, T, num_classes):
        super().__init__()
        self.T = T
        # 四个视图分别对应四个 CNN 子网络
        self.view1 = SingleViewCNN()
        self.view2 = SingleViewCNN()
        self.view3 = SingleViewCNN()
        #self.view4 = SingleViewCNN()

        # 合并特征并进行分类
        self.fc = nn.Sequential(
            nn.Linear(512, 16 * 4 * 4, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Linear(16 * 4 * 4, num_classes, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )
        self.attention = AttentionFusion(16)

    def forward(self, view1_a, view1_b, view2_a, view2_b, view3_a, view3_b):
        view1_a_dataset = [view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a, view1_a]
        view1_b_dataset = [view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b, view1_b]
        view2_a_dataset = [view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a, view2_a]
        view2_b_dataset = [view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b, view2_b]
        view3_a_dataset = [view3_a, view3_a, view3_a, view3_a, view3_a, view3_a, view3_a,
                           view3_a, view3_a, view3_a]
        view3_b_dataset = [view3_b, view3_b, view3_b, view3_b, view3_b, view3_b, view3_b, view3_b,
                         view3_b, view3_b]


        view1_a_data = view1_a_dataset[0]
        view1_b_data = view1_b_dataset[0]
        view2_a_data = view2_a_dataset[0]
        view2_b_data = view2_b_dataset[0]
        view3_a_data = view3_a_dataset[0]
        view3_b_data = view3_b_dataset[0]
        # 每个视图分别通过其对应的 CNN 网络
        feat1 = self.view1(view1_a_data, view1_b_data)
        feat2 = self.view2(view2_a_data, view2_b_data)
        feat3 = self.view3(view3_a_data, view3_b_data)
        #feat4 = self.view4(view4_data)

        fused_output, weight_1, weight_2, weight_3 = self.attention(feat1, feat2, feat3)
        #merged_feat = torch.cat((feat1, feat2, feat3), dim=1)
        out_spikes_counter = self.fc(fused_output)

        for t in range(1, self.T):
            view1_a_data = view1_a_dataset[t]
            view1_b_data = view1_b_dataset[t]
            view2_a_data = view2_a_dataset[t]
            view2_b_data = view2_b_dataset[t]
            view3_a_data = view3_a_dataset[t]
            view3_b_data = view3_b_dataset[t]
            # 每个视图分别通过其对应的 CNN 网络
            feat1 = self.view1(view1_a_data, view1_b_data)
            feat2 = self.view2(view2_a_data, view2_b_data)
            feat3 = self.view3(view3_a_data, view3_b_data)
            # 合并四个视图的特征
            fused_output, weight_1, weight_2, weight_3 = self.attention(feat1, feat2, feat3)
            out_spikes_counter += self.fc(fused_output)
        return out_spikes_counter / self.T

class SingleViewCNN(nn.Module):
    def __init__(self):
        super().__init__()
        # 定义CNN结构
        self.conv = nn.Sequential(
            # neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None,tau=2.0,v_threshold=1.0),
            neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Conv1d(1, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.Conv1d(16, 16, kernel_size=3, padding=1, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),

            nn.AvgPool1d(8, 8),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
            nn.Flatten()
        )


    def forward(self, drug_a, drug_b):
        rand = torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_a = drug_a.float()

        drug_b = drug_b.to('cuda') > torch.rand(drug_a.size(), device='cuda')
        drug_b = drug_b.float()

        # 通过共享CNN提取特征
        fea_a = self.conv(drug_a)
        fea_b = self.conv(drug_b)
        merged_feat = torch.cat((fea_a, fea_b), dim=1)
        return merged_feat


class AttentionFusion(nn.Module):
    def __init__(self, feature_dim):
        super(AttentionFusion, self).__init__()
        self.fc = nn.Linear(3232, 3)  # 3 views, so 3 attention weights
        self.fc1 = nn.Sequential(
            nn.Linear(1024, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

        self.fc2 = nn.Sequential(
            nn.Linear(1120, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

        self.fc3 = nn.Sequential(
            nn.Linear(1088, 512, bias=False),
            neuron.LIFNode(surrogate_function=surrogate.ATan(), v_reset=None, tau=2.0, v_threshold=0.5),
            # neuron.IFNode(surrogate_function=surrogate.ATan(), v_reset=None, v_threshold=1.0),
        )

    def forward(self, out1, out2, out3):
        # Concatenate features from the three views
        combined = torch.cat((out1, out2, out3), dim=1)  # (batch_size, 3 * feature_dim)

        # Calculate attention weights
        attention_weights = F.softmax(self.fc(combined), dim=1)  # (batch_size, 3)

        out1 = self.fc1(out1)
        out2 = self.fc2(out2)
        out3 = self.fc3(out3)

        # Apply attention to each view
        weighted_out1 = attention_weights[:, 0].unsqueeze(1) * out1
        weighted_out2 = attention_weights[:, 1].unsqueeze(1) * out2
        weighted_out3 = attention_weights[:, 2].unsqueeze(1) * out3

        weight_1 = attention_weights[:, 0].unsqueeze(1)
        weight_2 = attention_weights[:, 1].unsqueeze(1)
        weight_3 = attention_weights[:, 2].unsqueeze(1)

        # Combine the weighted outputs
        fused_output = weighted_out1 + weighted_out2 + weighted_out3

        return fused_output, weight_1, weight_2, weight_3

class DrugInteractionDataset(Dataset):
    def __init__(self, morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, labels):
        self.morgan_drug_a = morgan_drug_a
        self.morgan_drug_b = morgan_drug_b

        self.target_drug_a = target_drug_a
        self.target_drug_b = target_drug_b

        self.pathway_drug_a = pathway_drug_a
        self.pathway_drug_b = pathway_drug_b

        self.labels = labels  # 标签

    def __len__(self):
        return len(self.labels)  # 数据集长度

    def __getitem__(self, idx):
        # 返回第 idx 个 drug_a, drug_b 和对应的 label
        view1_a = self.morgan_drug_a[idx]
        view1_a = torch.tensor(view1_a)
        view1_a = view1_a.unsqueeze(0)

        view1_b = self.morgan_drug_b[idx]
        view1_b = torch.tensor(view1_b)
        view1_b = view1_b.unsqueeze(0)

        view2_a = self.target_drug_a[idx]
        view2_a = torch.tensor(view2_a)
        view2_a = view2_a.unsqueeze(0)

        view2_b = self.target_drug_b[idx]
        view2_b = torch.tensor(view2_b)
        view2_b = view2_b.unsqueeze(0)

        view3_a = self.pathway_drug_a[idx]
        view3_a = torch.tensor(view3_a)
        view3_a = view3_a.unsqueeze(0)

        view3_b = self.pathway_drug_b[idx]
        view3_b = torch.tensor(view3_b)
        view3_b = view3_b.unsqueeze(0)

        label = self.labels[idx]
        label = torch.tensor(label)
        return view1_a, view1_b, view2_a, view2_b, view3_a,  view3_b, label


def calculate_metrics(y_true, y_pred, y_val_bin, num_classes):
    y_pred_class = np.argmax(y_pred, axis=1)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(y_pred.shape[1]):
        fpr[i], tpr[i], _ = roc_curve(y_val_bin[:, i], y_pred[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    values = [v for v in roc_auc.values() if not np.isnan(v)]
    mean_value = np.mean(values)
    Auc = mean_value

    metrics = {}
    metrics['RMSE'] = np.sqrt(mean_squared_error(y_true, y_pred_class))
    metrics['PCC'], _ = pearsonr(y_true.flatten(), y_pred_class.flatten())
    metrics['ACC'] = accuracy_score(y_true, y_pred_class)
    metrics['Precision'] = precision_score(y_true, y_pred_class, average='macro')
    metrics['F1'] = f1_score(y_true, y_pred_class, average='macro')
    metrics['Recall'] = recall_score(y_true, y_pred_class, average='macro')
    metrics['AUC'] = Auc
    metrics['Kappa'] = cohen_kappa_score(y_true, y_pred_class)
    metrics['PREC'] = precision_score(y_true, y_pred_class, average='micro')  # 可以根据需求自定义

    return metrics
def main():

    current_directory = os.getcwd()
    folder_path = os.path.join(current_directory, 'data', '8anti_mat')
    mat_files = [f for f in os.listdir(folder_path) if f.endswith('.mat')]


    for mat_file in mat_files:
        # 保存当前文件名到变量
        current_file_name = mat_file[-11:-4]
        # 构建完整文件路径
        file_path = os.path.join(folder_path, mat_file)
       # 读取 .mat 文件
        mat_data = scipy.io.loadmat(file_path)
        morgan = mat_data['morgan']
        enzyme = mat_data['enzyme']
        target = mat_data['target']
        pathway = mat_data['pathway']
        gnd = np.squeeze(mat_data['gnd'])
        gnd_unique = np.unique(gnd)

        morgan_drug_a = morgan[:1926, :2049]
        morgan_drug_b = morgan[:1926, 2049:]

        target_drug_a = target[:1926, :2261]
        target_drug_b = target[:1926, 2261:]

        pathway_drug_a = pathway[:1926, :2186]
        pathway_drug_b = pathway[:1926, 2186:]

        enzyme_drug_a = enzyme[:1926, :330]
        enzyme_drug_b = enzyme[:1926, 330:]

        replace_dict = {old_value: new_value for new_value, old_value in enumerate(gnd_unique)}
        replace_func = np.vectorize(replace_dict.get)
        new_gnd = replace_func(gnd)
        dataset = DrugInteractionDataset(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, new_gnd)

        y_bin = label_binarize(new_gnd, classes=list(range(len(gnd_unique))))



        # 使用KFold划分数据
        kf = KFold(n_splits=5, shuffle=True, random_state=42)
        fold_results = []


        for fold, (train_idx, val_idx) in enumerate(kf.split(dataset)):
            print(f'Fold {fold}')
            train_dataset = Subset(dataset, train_idx)
            test_dataset = Subset(dataset, val_idx)
            y_val_bin = y_bin[val_idx]
            #train_dataset, test_dataset = random_split(dataset, [train_size, test_size])
            train_loader = DataLoader(dataset, batch_size=64, shuffle=False)
            test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)
            start_epoch = 0
            max_test_acc = 0
            parser = argparse.ArgumentParser(description='Classify Fashion-MNIST')
            parser.add_argument('-T', default=10, type=int, help='simulating time-steps')
            parser.add_argument('-device', default='cuda:0', help='device')
            parser.add_argument('-b', default=64, type=int, help='batch size')
            parser.add_argument('-epochs', default=1200, type=int, metavar='N',
                                help='number of total epochs to run')
            parser.add_argument('-j', default=1, type=int, metavar='N',
                                help='number of data loading workers (default: 4)')
            parser.add_argument('-out_dir', type=str, default='./logs', help='root dir for saving logs and checkpoint')
            parser.add_argument('-resume', type=str, help='resume from the checkpoint path')
            parser.add_argument('-amp', action='store_true', help='automatic mixed precision training')
            parser.add_argument('-opt', default='Adam', type=str, help='use which optimizer. SDG or Adam')
            parser.add_argument('-lr', default=0.001, type=float, help='learning rate')
            parser.add_argument('-momentum', default=0.9, type=float, help='momentum for SGD')
            parser.add_argument('-lr_scheduler', default='CosALR', type=str, help='use which schedule. StepLR or CosALR')
            parser.add_argument('-step_size', default=32, type=float, help='step_size for StepLR')
            parser.add_argument('-gamma', default=0.1, type=float, help='gamma for StepLR')
            parser.add_argument('-T_max', default=64, type=int, help='T_max for CosineAnnealingLR')
            args = parser.parse_args()
            print(args)
            # 初始化模型、损失函数和优化器
            net = MultiViewCNN(T=args.T,num_classes=len(gnd_unique))
            #net = SimpleNN(input_size=4098, num_classes=len(gnd_unique))
            net.to(args.device)#
            optimizer = None
            if args.opt == 'SDG':
                optimizer = torch.optim.SGD(net.parameters(), lr=args.lr, momentum=args.momentum)
            elif args.opt == 'Adam':
                optimizer = torch.optim.Adam(net.parameters(), lr=args.lr)
            else:
                raise NotImplementedError(args.opt)

            lr_scheduler = None
            if args.lr_scheduler == 'StepLR':
                lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=args.step_size, gamma=args.gamma)
            elif args.lr_scheduler == 'CosALR':
                lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.T_max)
            else:
                raise NotImplementedError(args.lr_scheduler)

            scaler = None
            if args.amp:
                scaler = amp.GradScaler()

            start_epoch = 0
            max_test_acc = 0

            if args.resume:
                checkpoint = torch.load(args.resume, map_location='cpu')
                net.load_state_dict(checkpoint['net'])
                optimizer.load_state_dict(checkpoint['optimizer'])
                lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
                start_epoch = checkpoint['epoch'] + 1
                max_test_acc = checkpoint['max_test_acc']

            out_dir = args.out_dir

            if not os.path.exists(out_dir):
                os.mkdir(out_dir)
                print(f'Mkdir {out_dir}.')

            with open(os.path.join(out_dir, 'args.txt'), 'w', encoding='utf-8') as args_txt:
                args_txt.write(str(args))

            writer = SummaryWriter(os.path.join(out_dir, 'TR_logs'), purge_step=start_epoch)

            for epoch in range(start_epoch, args.epochs):
                start_time = time.time()
                net.train()
                train_loss = 0
                train_acc = 0
                train_samples = 0
                for morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, label in train_loader:
                    optimizer.zero_grad()
                    label = label.to(args.device)
                    label = label.long()
                    label_onehot = F.one_hot(label, len(gnd_unique)).float()
                    if args.amp:
                        with amp.autocast():
                            out_fr = net(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a,
                                         pathway_drug_b)
                            loss = F.mse_loss(out_fr, label_onehot)
                        scaler.scale(loss).backward()
                        scaler.step(optimizer)
                        scaler.update()
                    else:
                        out_fr = net(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a,
                                     pathway_drug_b)
                        loss = F.mse_loss(out_fr, label_onehot)
                        loss.backward()
                        optimizer.step()

                    train_samples += label.numel()
                    train_loss += loss.item() * label.numel()
                    train_acc += (out_fr.argmax(1) == label).float().sum().item()

                    functional.reset_net(net)
                train_loss /= train_samples
                train_acc /= train_samples

                writer.add_scalar('train_loss', train_loss, epoch)
                writer.add_scalar('train_acc', train_acc, epoch)
                lr_scheduler.step()

                net.eval()
                test_loss = 0
                test_acc = 0
                test_samples = 0
                with torch.no_grad():
                    for morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, label in test_loader:
                        label = label.to(args.device)
                        label = label.long()
                        label_onehot = F.one_hot(label, len(gnd_unique)).float()
                        out_fr = net(morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a,
                                     pathway_drug_b)
                        loss = F.mse_loss(out_fr, label_onehot)

                        test_samples += label.numel()
                        test_loss += loss.item() * label.numel()
                        test_acc += (out_fr.argmax(1) == label).float().sum().item()
                        functional.reset_net(net)

                test_loss /= test_samples
                test_acc /= test_samples
                writer.add_scalar('test_loss', test_loss, epoch)
                writer.add_scalar('test_acc', test_acc, epoch)

                save_max = False
                if test_acc > max_test_acc:
                    max_test_acc = test_acc
                    save_max = True

                checkpoint = {
                    'net': net.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'lr_scheduler': lr_scheduler.state_dict(),
                    'epoch': epoch,
                    'max_test_acc': max_test_acc
                }

                if save_max:
                    # 获取当前工作目录
                    project_root = os.getcwd()

                    # 将当前工作目录与其他路径部分连接
                    model_path = os.path.join(project_root, 'logs', current_file_name + '.pth')
                    torch.save(net.state_dict(), model_path)

                torch.save(checkpoint, os.path.join(out_dir, 'checkpoint_latest.pth'))
                # torch.save(net.state_dict(), 'E:\Python_Project\ANN_2_SNN\Traffic_Reco\direct_train\SNN.pth' )
                #print(args)
                #print(out_dir)
                print(
                    f'epoch={epoch}, train_loss={train_loss}, train_acc={train_acc}, test_loss={test_loss}, test_acc={test_acc}, max_test_acc={max_test_acc}, total_time={time.time() - start_time}')

            # 实例化模型
            model = MultiViewCNN(T=args.T, num_classes=len(gnd_unique))
            # 加载已保存的模型权重
            project_root = os.getcwd()
            model.load_state_dict(torch.load(os.path.join(project_root, 'logs', current_file_name + '.pth')))
            # 设置模型为评估模式
            model.eval()
            # 将模型移动到GPU（如果有）
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            model.to(device)
            # 在测试集上运行模型
            with torch.no_grad():  # 关闭梯度计算
                for morgan_drug_a, morgan_drug_b, target_drug_a, target_drug_b, pathway_drug_a, pathway_drug_b, label in test_loader:
                    label = label.to(device)
                    label = label.long()
                    label_onehot = F.one_hot(label, len(gnd_unique)).float()
                    outputs, weight_1, weight_2, weight_3 = model(morgan_drug_a, morgan_drug_b, target_drug_a,
                                                                  target_drug_b, pathway_drug_a, pathway_drug_b)
                    _, predicted = torch.max(outputs, 1)
            predicted = predicted.cpu()
            label = label.cpu()
            label_onehot = label_onehot.cpu()
            label_onehot = label_onehot.numpy()
            outputs_np = outputs.cpu()
            outputs_np = outputs_np.numpy()

            val_pred, val_true = np.concatenate(all_outputs), np.concatenate(all_targets)
            metrics = calculate_metrics(val_true, val_pred,y_val_bin, num_classes=len(gnd_unique))
            fold_results.append(metrics)
        # 计算每个指标的均值和标准差
        final_results = {}
        for metric in fold_results[0].keys():
            values = [fold[metric] for fold in fold_results]
            final_results[f'{metric}_mean'] = np.mean(values)
            final_results[f'{metric}_std'] = np.std(values)

        # 保存结果到CSV
        current_directory = os.getcwd()
        output_dir = os.path.join(current_directory, 'data', 'table', 'SNRMPACDC')
        filename = current_file_name
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        output_path = os.path.join(output_dir, filename + '.csv')
        df = pd.DataFrame(final_results, index=[0])
        df.to_csv(output_path, index=False)
        result = current_file_name + "   Acc: " + str(final_results['ACC_mean'])
        print(result)

if __name__ == '__main__':
    main()