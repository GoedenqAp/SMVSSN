import csv
import os

# 输入和输出文件路径
current_directory = os.getcwd()
input_file = os.path.join(current_directory, 'data', '43anti_extract_interaction.csv')
output_file = 'output.csv'

# 打开输入文件进行读取
with open(input_file, 'r', newline='') as infile:
    reader = csv.reader(infile)

    # 打开输出文件进行写入
    with open(output_file, 'w', newline='') as outfile:
        writer = csv.writer(outfile)

        # 遍历输入文件的每一行
        for row in reader:
            # 检查第一列是否包含 "Binimetinib"
            if "Ibrutinib" in row[0]:
                # 写入筛选后的行，保留第1、2、5列
                writer.writerow([row[0], row[1], row[4]])
